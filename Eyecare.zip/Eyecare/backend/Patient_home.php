<?php
// test_connection.php - Test Database Connection
// Run this file to verify your database connection

require_once './backend/db_connect.php';

echo "<!DOCTYPE html>
<html>
<head>
    <title>Database Connection Test</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; }
        .success { color: green; background: #e6f7e6; padding: 15px; border-radius: 8px; border: 1px solid green; }
        .error { color: red; background: #fde8e8; padding: 15px; border-radius: 8px; border: 1px solid red; }
        .info { background: #f0f0f0; padding: 15px; border-radius: 8px; margin: 10px 0; }
        table { width: 100%; border-collapse: collapse; margin: 15px 0; }
        th, td { padding: 8px 12px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #f0f0f0; }
    </style>
</head>
<body>
    <h1>🔌 Database Connection Test</h1>";

// Get database info
$dbInfo = getDBInfo();

echo "<div class='info'>";
echo "<h3>Connection Details:</h3>";
echo "<p><strong>Host:</strong> " . $dbInfo['host'] . "</p>";
echo "<p><strong>Database:</strong> " . $dbInfo['name'] . "</p>";
echo "<p><strong>User:</strong> " . $dbInfo['user'] . "</p>";
echo "<p><strong>Charset:</strong> " . $dbInfo['charset'] . "</p>";
echo "<p><strong>Connected:</strong> " . ($dbInfo['connected'] ? '✅ Yes' : '❌ No') . "</p>";
echo "</div>";

if ($dbInfo['connected']) {
    echo "<div class='success'>✅ Database connected successfully!</div>";

    // Get all tables
    try {
        $db = getDB();
        $tables = $db->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);

        echo "<h3>📋 Tables in Database:</h3>";
        if (count($tables) > 0) {
            echo "<table>";
            echo "<tr><th>Table Name</th><th>Rows</th><th>Size (MB)</th></tr>";

            foreach ($tables as $table) {
                $stmt = $db->query("SELECT COUNT(*) as rows FROM $table");
                $rows = $stmt->fetch()['rows'];

                $stmt = $db->query("
                    SELECT ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 2) as size 
                    FROM information_schema.TABLES 
                    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = '$table'
                ");
                $size = $stmt->fetch()['size'] ?? 0;

                echo "<tr><td>$table</td><td>$rows</td><td>$size</td></tr>";
            }
            echo "</table>";
        } else {
            echo "<p>No tables found in database. Please run the schema setup.</p>";
        }
    } catch (Exception $e) {
        echo "<div class='error'>❌ Error fetching tables: " . $e->getMessage() . "</div>";
    }
} else {
    echo "<div class='error'>❌ Database connection failed!</div>";
    echo "<p>Please check your database credentials in <strong>dbconnect.php</strong></p>";
}

echo "
    <hr>
    <h3>⚡ Quick Test API</h3>
    <p>You can test your API endpoints:</p>
    <ul>
        <li><a href='backend.php/specializations'>/specializations</a></li>
        <li><a href='backend.php/doctors'>/doctors</a></li>
        <li><a href='backend.php/test-db'>/test-db</a></li>
    </ul>
</body>
</html>";
