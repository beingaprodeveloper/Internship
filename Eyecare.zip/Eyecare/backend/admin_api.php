<?php
// patient_appointment.php – Backend API for EyeCare Admin Panel

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// 🔒 Authentication check (optional – remove or adapt if not needed)
session_start();
// Uncomment below to enforce admin login
// if (!isset($_SESSION['user_id']) || strtolower($_SESSION['role']) !== 'admin') {
//     http_response_code(401);
//     echo json_encode(['error' => 'Unauthorized. Please log in as admin.']);
//     exit;
// }

// Include database connection
require_once __DIR__ . '/db_connect.php';

try {
    $pdo = getDBConnection();
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]);
    exit;
}

// Get action from request
$action = isset($_GET['action']) ? $_GET['action'] : '';
$method = $_SERVER['REQUEST_METHOD'];

// For POST requests, read raw JSON input
$input = json_decode(file_get_contents('php://input'), true) ?? [];

// Helper: send JSON response
function sendResponse($data, $status = 200)
{
    http_response_code($status);
    echo json_encode($data);
    exit;
}

// Helper: fetch all rows
function fetchAll($pdo, $sql, $params = [])
{
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Helper: fetch one row
function fetchOne($pdo, $sql, $params = [])
{
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// ---------- Handle actions ----------
switch ($action) {

    // ========== DASHBOARD STATS ==========
    case 'get_dashboard_stats':
        $totalDoctors = fetchOne($pdo, "SELECT COUNT(*) AS count FROM doctors")['count'] ?? 0;
        $totalPatients = fetchOne($pdo, "SELECT COUNT(*) AS count FROM users WHERE role = 'patient'")['count'] ?? 0;
        $totalAppointments = fetchOne($pdo, "SELECT COUNT(*) AS count FROM appointments")['count'] ?? 0;
        $todayAppointments = fetchOne($pdo, "SELECT COUNT(*) AS count FROM appointments WHERE DATE(appointment_date) = CURDATE()")['count'] ?? 0;
        sendResponse([
            'status' => 'success',
            'data' => [
                'total_doctors'      => (int)$totalDoctors,
                'total_patients'     => (int)$totalPatients,
                'total_appointments' => (int)$totalAppointments,
                'today_appointments' => (int)$todayAppointments
            ]
        ]);
        break;

    // ========== RECENT APPOINTMENTS (with pagination) ==========
    case 'get_recent_appointments':
        $page = (int)($_GET['page'] ?? 1);
        $limit = (int)($_GET['limit'] ?? 3);
        $offset = ($page - 1) * $limit;
        try {
            $sql = "SELECT 
                        a.appointment_id AS id,
                        u.full_name AS patient_name,
                        d.name AS doctor_name,
                        a.appointment_date,
                        a.start_time,
                        a.status
                    FROM appointments a
                    LEFT JOIN users u ON a.patient_id = u.user_id
                    LEFT JOIN doctors d ON a.provider_id = d.id
                    ORDER BY a.appointment_date DESC
                    LIMIT :limit OFFSET :offset";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();
            $appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $countStmt = $pdo->query("SELECT COUNT(*) AS total FROM appointments");
            $total = $countStmt->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;
            sendResponse([
                'status' => 'success',
                'data' => $appointments,
                'pagination' => [
                    'current_page' => $page,
                    'total_pages'  => ceil($total / $limit),
                    'total_items'  => (int)$total
                ]
            ]);
        } catch (PDOException $e) {
            sendResponse(['status' => 'error', 'message' => $e->getMessage()], 500);
        }
        break;

    // ========== SPECIALIZATIONS ==========
    case 'get_specializations':
        $specs = fetchAll($pdo, "SELECT * FROM specializations ORDER BY name");
        sendResponse($specs);
        break;

    case 'add_specialization':
        if ($method !== 'POST') sendResponse(['error' => 'Method not allowed'], 405);
        $name = trim($input['name'] ?? '');
        $icon = trim($input['icon'] ?? '👁️');
        if (empty($name)) sendResponse(['error' => 'Name is required'], 400);
        $stmt = $pdo->prepare("INSERT INTO specializations (name, icon) VALUES (:name, :icon)");
        $stmt->execute([':name' => $name, ':icon' => $icon]);
        sendResponse(['success' => true, 'id' => $pdo->lastInsertId()]);
        break;

    case 'update_specialization':
        if ($method !== 'POST') sendResponse(['error' => 'Method not allowed'], 405);
        $id = (int)($input['id'] ?? 0);
        $name = trim($input['name'] ?? '');
        $icon = trim($input['icon'] ?? '👁️');
        if (!$id || empty($name)) sendResponse(['error' => 'ID and name are required'], 400);
        $stmt = $pdo->prepare("UPDATE specializations SET name = :name, icon = :icon WHERE id = :id");
        $stmt->execute([':name' => $name, ':icon' => $icon, ':id' => $id]);
        sendResponse(['success' => true]);
        break;

    case 'delete_specialization':
        if ($method !== 'POST') sendResponse(['error' => 'Method not allowed'], 405);
        $id = (int)($input['id'] ?? 0);
        if (!$id) sendResponse(['error' => 'ID is required'], 400);
        $stmt = $pdo->prepare("DELETE FROM specializations WHERE id = :id");
        $stmt->execute([':id' => $id]);
        sendResponse(['success' => true]);
        break;

    // ========== DOCTORS ==========
    case 'get_doctors':
        $doctors = fetchAll($pdo, "SELECT * FROM doctors ORDER BY name");
        sendResponse($doctors);
        break;

    case 'add_doctor':
        if ($method !== 'POST') sendResponse(['error' => 'Method not allowed'], 405);
        $data = $input;
        $required = ['name', 'specialization_id', 'fee'];
        foreach ($required as $field) {
            if (empty($data[$field])) sendResponse(['error' => "Field '$field' is required"], 400);
        }
        $stmt = $pdo->prepare("
            INSERT INTO doctors (
                name, gender, specialization_id, photo, qualification, experience,
                languages, fee, rating, patients_treated, available_today, biography,
                certifications, hospital_branch, working_days, working_hours_start,
                working_hours_end, slot_duration
            ) VALUES (
                :name, :gender, :specialization_id, :photo, :qualification, :experience,
                :languages, :fee, :rating, :patients_treated, :available_today, :biography,
                :certifications, :hospital_branch, :working_days, :working_hours_start,
                :working_hours_end, :slot_duration
            )
        ");
        $params = [
            ':name' => $data['name'],
            ':gender' => $data['gender'] ?? 'male',
            ':specialization_id' => (int)$data['specialization_id'],
            ':photo' => $data['photo'] ?? '👨',
            ':qualification' => $data['qualification'] ?? '',
            ':experience' => $data['experience'] ?? '',
            ':languages' => $data['languages'] ?? '',
            ':fee' => (float)$data['fee'],
            ':rating' => (float)($data['rating'] ?? 0),
            ':patients_treated' => (int)($data['patients_treated'] ?? 0),
            ':available_today' => isset($data['available_today']) ? (int)$data['available_today'] : 1,
            ':biography' => $data['biography'] ?? '',
            ':certifications' => $data['certifications'] ?? '',
            ':hospital_branch' => $data['hospital_branch'] ?? '',
            ':working_days' => $data['working_days'] ?? '',
            ':working_hours_start' => $data['working_hours_start'] ?? '09:00:00',
            ':working_hours_end' => $data['working_hours_end'] ?? '17:00:00',
            ':slot_duration' => (int)($data['slot_duration'] ?? 15),
        ];
        $stmt->execute($params);
        $doctorId = $pdo->lastInsertId();
        sendResponse(['success' => true, 'id' => $doctorId]);
        break;

    case 'update_doctor':
        if ($method !== 'POST') sendResponse(['error' => 'Method not allowed'], 405);
        $data = $input;
        if (empty($data['id'])) sendResponse(['error' => 'Doctor ID is required'], 400);
        $id = (int)$data['id'];
        $stmt = $pdo->prepare("
            UPDATE doctors SET
                name = :name,
                gender = :gender,
                specialization_id = :specialization_id,
                photo = :photo,
                qualification = :qualification,
                experience = :experience,
                languages = :languages,
                fee = :fee,
                rating = :rating,
                patients_treated = :patients_treated,
                available_today = :available_today,
                biography = :biography,
                certifications = :certifications,
                hospital_branch = :hospital_branch,
                working_days = :working_days,
                working_hours_start = :working_hours_start,
                working_hours_end = :working_hours_end,
                slot_duration = :slot_duration
            WHERE id = :id
        ");
        $params = [
            ':id' => $id,
            ':name' => $data['name'] ?? '',
            ':gender' => $data['gender'] ?? 'male',
            ':specialization_id' => (int)($data['specialization_id'] ?? 0),
            ':photo' => $data['photo'] ?? '👨',
            ':qualification' => $data['qualification'] ?? '',
            ':experience' => $data['experience'] ?? '',
            ':languages' => $data['languages'] ?? '',
            ':fee' => (float)($data['fee'] ?? 0),
            ':rating' => (float)($data['rating'] ?? 0),
            ':patients_treated' => (int)($data['patients_treated'] ?? 0),
            ':available_today' => isset($data['available_today']) ? (int)$data['available_today'] : 1,
            ':biography' => $data['biography'] ?? '',
            ':certifications' => $data['certifications'] ?? '',
            ':hospital_branch' => $data['hospital_branch'] ?? '',
            ':working_days' => $data['working_days'] ?? '',
            ':working_hours_start' => $data['working_hours_start'] ?? '09:00:00',
            ':working_hours_end' => $data['working_hours_end'] ?? '17:00:00',
            ':slot_duration' => (int)($data['slot_duration'] ?? 15),
        ];
        $stmt->execute($params);
        sendResponse(['success' => true]);
        break;

    case 'delete_doctor':
        if ($method !== 'POST') sendResponse(['error' => 'Method not allowed'], 405);
        $id = (int)($input['id'] ?? 0);
        if (!$id) sendResponse(['error' => 'ID is required'], 400);
        $stmt = $pdo->prepare("DELETE FROM doctors WHERE id = :id");
        $stmt->execute([':id' => $id]);
        sendResponse(['success' => true]);
        break;

    // ========== TREATMENTS ==========
    case 'get_treatments':
        $treatments = fetchAll($pdo, "SELECT * FROM treatments ORDER BY name");
        sendResponse($treatments);
        break;

    case 'add_treatment':
        if ($method !== 'POST') sendResponse(['error' => 'Method not allowed'], 405);
        $data = $input;
        $required = ['specialization_id', 'name', 'consult_fee'];
        foreach ($required as $field) {
            if (empty($data[$field]) && $data[$field] !== 0) sendResponse(['error' => "Field '$field' is required"], 400);
        }
        $stmt = $pdo->prepare("
            INSERT INTO treatments (
                specialization_id, name, description, duration, consult_fee, surgery_fee,
                recovery, package_name, package_price, package_includes
            ) VALUES (
                :specialization_id, :name, :description, :duration, :consult_fee, :surgery_fee,
                :recovery, :package_name, :package_price, :package_includes
            )
        ");
        $params = [
            ':specialization_id' => (int)$data['specialization_id'],
            ':name' => $data['name'],
            ':description' => $data['description'] ?? '',
            ':duration' => $data['duration'] ?? '',
            ':consult_fee' => (float)$data['consult_fee'],
            ':surgery_fee' => isset($data['surgery_fee']) && $data['surgery_fee'] !== '' ? (float)$data['surgery_fee'] : null,
            ':recovery' => $data['recovery'] ?? '',
            ':package_name' => $data['package_name'] ?? '',
            ':package_price' => isset($data['package_price']) && $data['package_price'] !== '' ? (float)$data['package_price'] : null,
            ':package_includes' => $data['package_includes'] ?? '',
        ];
        $stmt->execute($params);
        sendResponse(['success' => true, 'id' => $pdo->lastInsertId()]);
        break;

    case 'update_treatment':
        if ($method !== 'POST') sendResponse(['error' => 'Method not allowed'], 405);
        $data = $input;
        if (empty($data['id'])) sendResponse(['error' => 'Treatment ID required'], 400);
        $id = (int)$data['id'];
        $stmt = $pdo->prepare("
            UPDATE treatments SET
                specialization_id = :specialization_id,
                name = :name,
                description = :description,
                duration = :duration,
                consult_fee = :consult_fee,
                surgery_fee = :surgery_fee,
                recovery = :recovery,
                package_name = :package_name,
                package_price = :package_price,
                package_includes = :package_includes
            WHERE id = :id
        ");
        $params = [
            ':id' => $id,
            ':specialization_id' => (int)($data['specialization_id'] ?? 0),
            ':name' => $data['name'] ?? '',
            ':description' => $data['description'] ?? '',
            ':duration' => $data['duration'] ?? '',
            ':consult_fee' => (float)($data['consult_fee'] ?? 0),
            ':surgery_fee' => isset($data['surgery_fee']) && $data['surgery_fee'] !== '' ? (float)$data['surgery_fee'] : null,
            ':recovery' => $data['recovery'] ?? '',
            ':package_name' => $data['package_name'] ?? '',
            ':package_price' => isset($data['package_price']) && $data['package_price'] !== '' ? (float)$data['package_price'] : null,
            ':package_includes' => $data['package_includes'] ?? '',
        ];
        $stmt->execute($params);
        sendResponse(['success' => true]);
        break;

    case 'delete_treatment':
        if ($method !== 'POST') sendResponse(['error' => 'Method not allowed'], 405);
        $id = (int)($input['id'] ?? 0);
        if (!$id) sendResponse(['error' => 'ID is required'], 400);
        $stmt = $pdo->prepare("DELETE FROM treatments WHERE id = :id");
        $stmt->execute([':id' => $id]);
        sendResponse(['success' => true]);
        break;

    // ========== UPDATE DOCTOR TREATMENTS (many-to-many) ==========
    case 'update_doctor_treatments':
        if ($method !== 'POST') sendResponse(['error' => 'Method not allowed'], 405);
        $doctorId = (int)($input['doctor_id'] ?? 0);
        $treatmentIds = $input['treatment_ids'] ?? [];
        if (!$doctorId) sendResponse(['error' => 'Doctor ID required'], 400);
        // Optionally, implement a doctor_treatments junction table.
        // For simplicity, this example stores treatment IDs as comma-separated in the doctors table.
        // We'll update the 'treatments' column.
        $treatmentsStr = implode(',', array_map('intval', $treatmentIds));
        $stmt = $pdo->prepare("UPDATE doctors SET treatments = :treatments WHERE id = :id");
        $stmt->execute([':treatments' => $treatmentsStr, ':id' => $doctorId]);
        sendResponse(['success' => true]);
        break;

    // ========== AUTH CHECK (optional) ==========
    case 'check_auth':
        sendResponse([
            'status' => 'success',
            'user' => [
                'name' => $_SESSION['full_name'] ?? 'Admin',
                'role' => 'Admin'
            ]
        ]);
        break;

    default:
        sendResponse(['error' => 'Invalid action'], 400);
        break;
}
