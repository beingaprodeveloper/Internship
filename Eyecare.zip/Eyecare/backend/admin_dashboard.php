<?php
// backend/admin_dashboard.php
header('Content-Type: application/json');
session_start();

// Enable error reporting for debugging (remove later)
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once 'db_connect.php';

// Authentication
if (!isset($_SESSION['user_id']) || strtolower($_SESSION['role']) !== 'admin') {
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    $pdo = getDBConnection();
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Database connection failed: ' . $e->getMessage()]);
    exit;
}

// Helper functions (with try-catch)
function safeFetchOne($pdo, $sql, $params = [])
{
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("safeFetchOne error: " . $e->getMessage());
        return null;
    }
}

function safeFetchAll($pdo, $sql, $params = [])
{
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("safeFetchAll error: " . $e->getMessage());
        return [];
    }
}

function tableExists($pdo, $table)
{
    try {
        $stmt = $pdo->query("SHOW TABLES LIKE '$table'");
        return $stmt && $stmt->rowCount() > 0;
    } catch (PDOException $e) {
        error_log("tableExists error: " . $e->getMessage());
        return false;
    }
}

// --- 1. Get user profile ---
$userData = safeFetchOne($pdo, "
    SELECT 
        user_id,
        full_name,
        username,
        email,
        phone,
        gender,
        dob,
        address,
        profile_image,
        status,
        role,
        created_at,
        updated_at
    FROM users 
    WHERE user_id = ?
", [$user_id]);

if (!$userData) {
    $userData = [
        'full_name' => $_SESSION['full_name'] ?? 'Administrator',
        'username'  => $_SESSION['username'] ?? 'admin',
        'email'     => $_SESSION['email'] ?? 'admin@example.com',
        'phone'     => '—',
        'gender'    => '—',
        'dob'       => '—',
        'address'   => '—',
        'profile_image' => null,
        'status'    => 'active',
        'role'      => 'admin',
        'created_at' => date('Y-m-d H:i:s'),
        'updated_at' => date('Y-m-d H:i:s'),
    ];
}

$user = [
    'full_name'      => $userData['full_name'] ?? 'Administrator',
    'username'       => $userData['username'] ?? 'admin',
    'email'          => $userData['email'] ?? 'admin@example.com',
    'phone'          => $userData['phone'] ?? '—',
    'gender'         => $userData['gender'] ?? '—',
    'dob'            => $userData['dob'] ?? '—',
    'address'        => $userData['address'] ?? '—',
    'profile_image'  => $userData['profile_image'] ?? null,
    'status'         => $userData['status'] ?? 'active',
    'role'           => $userData['role'] ?? 'admin',
    'created_at'     => $userData['created_at'] ?? date('Y-m-d H:i:s'),
    'updated_at'     => $userData['updated_at'] ?? date('Y-m-d H:i:s'),
];

$userInitials = implode('', array_map(fn($w) => $w[0], explode(' ', $user['full_name'])));
$user['initials'] = strtoupper(substr($userInitials, 0, 2));

// --- 2. Dashboard stats (live computed) ---
// We compute everything directly – no reliance on dashboard_stats table.
$stats = [
    'total_users'              => safeFetchOne($pdo, "SELECT COUNT(*) AS c FROM users")['c'] ?? 0,
    'total_doctors'            => safeFetchOne($pdo, "SELECT COUNT(*) AS c FROM doctors")['c'] ?? 0,
    'total_patients'           => safeFetchOne($pdo, "SELECT COUNT(*) AS c FROM users WHERE role = 'patient'")['c'] ?? 0,
    'total_admins'             => safeFetchOne($pdo, "SELECT COUNT(*) AS c FROM users WHERE role = 'admin'")['c'] ?? 0,
    'active_users'             => safeFetchOne($pdo, "SELECT COUNT(*) AS c FROM users WHERE status = 'active'")['c'] ?? 0,
    'inactive_users'           => safeFetchOne($pdo, "SELECT COUNT(*) AS c FROM users WHERE status = 'inactive'")['c'] ?? 0,
    'suspended_users'          => safeFetchOne($pdo, "SELECT COUNT(*) AS c FROM users WHERE status = 'suspended'")['c'] ?? 0,
    'total_specializations'    => safeFetchOne($pdo, "SELECT COUNT(*) AS c FROM specializations")['c'] ?? 0,
    'total_treatments'         => safeFetchOne($pdo, "SELECT COUNT(*) AS c FROM treatments")['c'] ?? 0,
    'total_appointments'       => safeFetchOne($pdo, "SELECT COUNT(*) AS c FROM appointments")['c'] ?? 0,
    'today_appointments'       => safeFetchOne($pdo, "SELECT COUNT(*) AS c FROM appointments WHERE DATE(appointment_date) = CURDATE()")['c'] ?? 0,
    'upcoming_appointments'    => safeFetchOne($pdo, "SELECT COUNT(*) AS c FROM appointments WHERE appointment_date > CURDATE() AND status NOT IN ('cancelled','completed','no-show')")['c'] ?? 0,
    'completed_appointments'   => safeFetchOne($pdo, "SELECT COUNT(*) AS c FROM appointments WHERE status = 'completed'")['c'] ?? 0,
    'cancelled_appointments'   => safeFetchOne($pdo, "SELECT COUNT(*) AS c FROM appointments WHERE status = 'cancelled'")['c'] ?? 0,
    'no_show_appointments'     => safeFetchOne($pdo, "SELECT COUNT(*) AS c FROM appointments WHERE status = 'no_show'")['c'] ?? 0,
    'total_premium_bookings'   => safeFetchOne($pdo, "SELECT COUNT(*) AS c FROM premium_bookings")['c'] ?? 0,
    'pending_premium'          => safeFetchOne($pdo, "SELECT COUNT(*) AS c FROM premium_bookings WHERE status = 'pending'")['c'] ?? 0,
    'confirmed_premium'        => safeFetchOne($pdo, "SELECT COUNT(*) AS c FROM premium_bookings WHERE status = 'confirmed'")['c'] ?? 0,
    'completed_premium'        => safeFetchOne($pdo, "SELECT COUNT(*) AS c FROM premium_bookings WHERE status = 'completed'")['c'] ?? 0,
    'cancelled_premium'        => safeFetchOne($pdo, "SELECT COUNT(*) AS c FROM premium_bookings WHERE status = 'cancelled'")['c'] ?? 0,
    'available_doctors'        => safeFetchOne($pdo, "SELECT COUNT(*) AS c FROM doctors WHERE availability = 'available'")['c'] ?? 0,
    'unavailable_doctors'      => safeFetchOne($pdo, "SELECT COUNT(*) AS c FROM doctors WHERE availability = 'unavailable'")['c'] ?? 0,
    'unread_notifications'     => safeFetchOne($pdo, "SELECT COUNT(*) AS c FROM notifications WHERE is_read = 0")['c'] ?? 0,
    'total_notifications'      => safeFetchOne($pdo, "SELECT COUNT(*) AS c FROM notifications")['c'] ?? 0,
    'total_audit_logs'         => safeFetchOne($pdo, "SELECT COUNT(*) AS c FROM audit_logs")['c'] ?? 0,
];

// --- 3. Recent appointments (latest 10 for better overview) ---
$appointments = [];
if (tableExists($pdo, 'appointments')) {
    $sql = "SELECT a.appointment_id, u.full_name AS patient_name, d.name AS doctor_name,
                   a.appointment_date, a.start_time, a.status
            FROM appointments a
            LEFT JOIN users u ON a.patient_id = u.user_id
            LEFT JOIN doctors d ON a.provider_id = d.id
            ORDER BY a.appointment_date DESC, a.start_time DESC
            LIMIT 10";
    $appointments = safeFetchAll($pdo, $sql);
}

// --- 4. Recent notifications (latest 5) ---
$notifications = [];
if (tableExists($pdo, 'notifications')) {
    $notifications = safeFetchAll($pdo, "SELECT * FROM notifications ORDER BY created_at DESC LIMIT 5");
}

// --- 5. Recent audit logs (latest 5) ---
$auditLogs = [];
if (tableExists($pdo, 'audit_logs')) {
    $auditLogs = safeFetchAll($pdo, "SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 5");
}

// --- 6. Chart data ---
$chartLabels = [];
$chartValues = [];
$statusLabels = ['Scheduled', 'Completed', 'Cancelled', 'No Show'];
$statusValues = [];

if (tableExists($pdo, 'appointments')) {
    // Last 7 days trend
    for ($i = 6; $i >= 0; $i--) {
        $date = date('Y-m-d', strtotime("-$i days"));
        $chartLabels[] = date('D', strtotime($date));
        $count = safeFetchOne($pdo, "SELECT COUNT(*) AS c FROM appointments WHERE DATE(appointment_date) = :date", [':date' => $date])['c'] ?? 0;
        $chartValues[] = $count;
    }

    // Status distribution
    $statusMap = ['scheduled' => 'Scheduled', 'completed' => 'Completed', 'cancelled' => 'Cancelled', 'no_show' => 'No Show'];
    foreach ($statusMap as $dbStatus => $label) {
        $count = safeFetchOne($pdo, "SELECT COUNT(*) AS c FROM appointments WHERE status = :status", [':status' => $dbStatus])['c'] ?? 0;
        $statusValues[] = $count;
    }
}

$chart = [
    'labels' => $chartLabels,
    'values' => $chartValues,
    'status_labels' => $statusLabels,
    'status_values' => $statusValues,
];

// --- 7. Build final response ---
$response = [
    'status' => 'success',
    'user' => $user,
    'stats' => $stats,
    'appointments' => $appointments,
    'notifications' => $notifications,
    'audit_logs' => $auditLogs,
    'chart' => $chart,
];

echo json_encode($response);
