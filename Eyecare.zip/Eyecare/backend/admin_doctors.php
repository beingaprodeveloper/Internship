<?php

/**
 * EyeCare Plus - Doctors Module API
 * All responses are JSON.
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');

function jsonResponse($success, $message = '', $data = null)
{
    $response = ['success' => $success, 'message' => $message];
    if ($data !== null) {
        $response['data'] = $data;
    }
    echo json_encode($response);
    exit;
}

try {
    require_once __DIR__ . '/db_connect.php';  // Your db_connect.php creates $pdo globally

    if (!isset($pdo)) {
        throw new Exception('Database connection not established.');
    }

    // --- Helper functions ---
    function getDoctorById($pdo, $id)
    {
        $stmt = $pdo->prepare("SELECT * FROM doctors WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    function getAppointmentsForDoctor($pdo, $doctorId)
    {
        try {
            $stmt = $pdo->query("SHOW TABLES LIKE 'appointments'");
            if ($stmt->rowCount() == 0) {
                return [];
            }
            $stmt = $pdo->prepare("SELECT * FROM appointments WHERE doctor_id = ? ORDER BY date DESC, time DESC");
            $stmt->execute([$doctorId]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }

    function getAppointmentCount($pdo, $doctorId)
    {
        try {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM appointments WHERE doctor_id = ?");
            $stmt->execute([$doctorId]);
            return (int)$stmt->fetchColumn();
        } catch (PDOException $e) {
            return 0;
        }
    }

    // Test endpoint – visit ?test=1 to check if the API is alive
    if (isset($_GET['test'])) {
        jsonResponse(true, 'Backend is working!', ['timestamp' => date('Y-m-d H:i:s')]);
    }

    $action = isset($_POST['action']) ? $_POST['action'] : '';

    switch ($action) {
        case 'list':
            $stmt = $pdo->query("SELECT * FROM doctors ORDER BY name");
            $doctors = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($doctors as &$doc) {
                $doc['appointment_count'] = getAppointmentCount($pdo, $doc['id']);
                $doc['working_days'] = $doc['working_days'] ?: '[]';
                $doc['holidays'] = $doc['holidays'] ?: '[]';
                $doc['blocked_slots'] = $doc['blocked_slots'] ?: '[]';
                $doc['languages'] = $doc['languages'] ? json_decode($doc['languages'], true) : [];
            }
            jsonResponse(true, 'Doctors fetched', ['doctors' => $doctors]);
            break;

        case 'getDoctor':
            $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
            if ($id <= 0) jsonResponse(false, 'Invalid doctor ID');
            $doctor = getDoctorById($pdo, $id);
            if (!$doctor) jsonResponse(false, 'Doctor not found');
            $doctor['working_days'] = $doctor['working_days'] ?: '[]';
            $doctor['holidays'] = $doctor['holidays'] ?: '[]';
            $doctor['blocked_slots'] = $doctor['blocked_slots'] ?: '[]';
            $doctor['languages'] = $doctor['languages'] ? json_decode($doctor['languages'], true) : [];
            $appointments = getAppointmentsForDoctor($pdo, $id);
            jsonResponse(true, 'Doctor fetched', ['doctor' => $doctor, 'appointments' => $appointments]);
            break;

        case 'toggleDoctor':
            $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
            if ($id <= 0) jsonResponse(false, 'Invalid doctor ID');
            $doctor = getDoctorById($pdo, $id);
            if (!$doctor) jsonResponse(false, 'Doctor not found');
            $newStatus = $doctor['available_today'] ? 0 : 1;
            $stmt = $pdo->prepare("UPDATE doctors SET available_today = ? WHERE id = ?");
            if ($stmt->execute([$newStatus, $id])) {
                jsonResponse(true, 'Doctor ' . ($newStatus ? 'enabled' : 'disabled') . ' successfully.');
            } else {
                jsonResponse(false, 'Failed to update doctor status.');
            }
            break;

        case 'updateDoctor':
            $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
            if ($id <= 0) jsonResponse(false, 'Invalid doctor ID');
            $name = isset($_POST['name']) ? trim($_POST['name']) : '';
            if (empty($name)) jsonResponse(false, 'Name is required');
            $specialization = isset($_POST['specialization']) ? trim($_POST['specialization']) : '';
            $qualification = isset($_POST['qualification']) ? trim($_POST['qualification']) : '';
            $experience = isset($_POST['experience']) ? (int)$_POST['experience'] : 0;
            $languages = isset($_POST['languages']) ? json_encode($_POST['languages']) : '[]';
            $fee = isset($_POST['fee']) ? (float)$_POST['fee'] : 0;
            $rating = isset($_POST['rating']) ? (float)$_POST['rating'] : 4.5;
            $slot_duration = isset($_POST['slot_duration']) ? (int)$_POST['slot_duration'] : 15;
            $gender = isset($_POST['gender']) ? $_POST['gender'] : 'other';
            $photo = isset($_POST['photo']) ? $_POST['photo'] : '👨';
            $working_hours_start = isset($_POST['working_hours_start']) ? $_POST['working_hours_start'] : '09:00';
            $working_hours_end = isset($_POST['working_hours_end']) ? $_POST['working_hours_end'] : '17:00';
            $working_days = isset($_POST['working_days']) ? json_encode($_POST['working_days']) : '[]';

            $stmt = $pdo->prepare("
                UPDATE doctors 
                SET name = ?, specialization = ?, qualification = ?, experience = ?, 
                    languages = ?, fee = ?, rating = ?, slot_duration = ?, 
                    gender = ?, photo = ?, working_hours_start = ?, working_hours_end = ?, 
                    working_days = ?
                WHERE id = ?
            ");
            if ($stmt->execute([
                $name,
                $specialization,
                $qualification,
                $experience,
                $languages,
                $fee,
                $rating,
                $slot_duration,
                $gender,
                $photo,
                $working_hours_start,
                $working_hours_end,
                $working_days,
                $id
            ])) {
                jsonResponse(true, 'Doctor updated successfully.');
            } else {
                jsonResponse(false, 'Failed to update doctor.');
            }
            break;

        case 'addHoliday':
            $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
            $date = isset($_POST['date']) ? $_POST['date'] : '';
            if ($id <= 0 || empty($date)) jsonResponse(false, 'Invalid parameters');
            $doctor = getDoctorById($pdo, $id);
            if (!$doctor) jsonResponse(false, 'Doctor not found');
            $holidays = $doctor['holidays'] ? json_decode($doctor['holidays'], true) : [];
            if (!in_array($date, $holidays)) {
                $holidays[] = $date;
                $stmt = $pdo->prepare("UPDATE doctors SET holidays = ? WHERE id = ?");
                if ($stmt->execute([json_encode($holidays), $id])) {
                    jsonResponse(true, 'Holiday added successfully.');
                } else {
                    jsonResponse(false, 'Failed to add holiday.');
                }
            } else {
                jsonResponse(false, 'Holiday already exists.');
            }
            break;

        case 'removeHoliday':
            $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
            $date = isset($_POST['date']) ? $_POST['date'] : '';
            if ($id <= 0 || empty($date)) jsonResponse(false, 'Invalid parameters');
            $doctor = getDoctorById($pdo, $id);
            if (!$doctor) jsonResponse(false, 'Doctor not found');
            $holidays = $doctor['holidays'] ? json_decode($doctor['holidays'], true) : [];
            $holidays = array_values(array_filter($holidays, function ($d) use ($date) {
                return $d !== $date;
            }));
            $stmt = $pdo->prepare("UPDATE doctors SET holidays = ? WHERE id = ?");
            if ($stmt->execute([json_encode($holidays), $id])) {
                jsonResponse(true, 'Holiday removed successfully.');
            } else {
                jsonResponse(false, 'Failed to remove holiday.');
            }
            break;

        case 'addBlockedSlot':
            $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
            $date = isset($_POST['date']) ? $_POST['date'] : '';
            $time = isset($_POST['time']) ? $_POST['time'] : '';
            if ($id <= 0 || empty($date) || empty($time)) jsonResponse(false, 'Invalid parameters');
            $doctor = getDoctorById($pdo, $id);
            if (!$doctor) jsonResponse(false, 'Doctor not found');
            $blocked = $doctor['blocked_slots'] ? json_decode($doctor['blocked_slots'], true) : [];
            $newBlock = ['date' => $date, 'time' => $time];
            $exists = false;
            foreach ($blocked as $b) {
                if ($b['date'] === $date && $b['time'] === $time) {
                    $exists = true;
                    break;
                }
            }
            if (!$exists) {
                $blocked[] = $newBlock;
                $stmt = $pdo->prepare("UPDATE doctors SET blocked_slots = ? WHERE id = ?");
                if ($stmt->execute([json_encode($blocked), $id])) {
                    jsonResponse(true, 'Slot blocked successfully.');
                } else {
                    jsonResponse(false, 'Failed to block slot.');
                }
            } else {
                jsonResponse(false, 'Slot already blocked.');
            }
            break;

        case 'removeBlockedSlot':
            $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
            $date = isset($_POST['date']) ? $_POST['date'] : '';
            $time = isset($_POST['time']) ? $_POST['time'] : '';
            if ($id <= 0 || empty($date) || empty($time)) jsonResponse(false, 'Invalid parameters');
            $doctor = getDoctorById($pdo, $id);
            if (!$doctor) jsonResponse(false, 'Doctor not found');
            $blocked = $doctor['blocked_slots'] ? json_decode($doctor['blocked_slots'], true) : [];
            $blocked = array_values(array_filter($blocked, function ($b) use ($date, $time) {
                return !($b['date'] === $date && $b['time'] === $time);
            }));
            $stmt = $pdo->prepare("UPDATE doctors SET blocked_slots = ? WHERE id = ?");
            if ($stmt->execute([json_encode($blocked), $id])) {
                jsonResponse(true, 'Blocked slot removed successfully.');
            } else {
                jsonResponse(false, 'Failed to remove blocked slot.');
            }
            break;

        case 'cancelAppointment':
            $appointmentId = isset($_POST['appointmentId']) ? (int)$_POST['appointmentId'] : 0;
            if ($appointmentId <= 0) jsonResponse(false, 'Invalid appointment ID');
            try {
                $stmt = $pdo->query("SHOW TABLES LIKE 'appointments'");
                if ($stmt->rowCount() == 0) {
                    jsonResponse(false, 'Appointments table does not exist.');
                }
                $stmt = $pdo->prepare("DELETE FROM appointments WHERE id = ?");
                if ($stmt->execute([$appointmentId])) {
                    jsonResponse(true, 'Appointment cancelled successfully.');
                } else {
                    jsonResponse(false, 'Failed to cancel appointment.');
                }
            } catch (PDOException $e) {
                jsonResponse(false, 'Database error: ' . $e->getMessage());
            }
            break;

        default:
            jsonResponse(false, 'Invalid action.');
    }
} catch (Exception $e) {
    jsonResponse(false, 'Server error: ' . $e->getMessage());
}
