<?php
// backend/auth_check.php
// This file checks if user is logged in via PHP session

// Start session at the VERY beginning
session_start();
header('Content-Type: application/json');

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

function logMessage($msg)
{
    error_log("AUTH_CHECK: " . $msg);
}

try {
    logMessage("=== AUTH CHECK START ===");
    logMessage("Session ID: " . session_id());
    logMessage("Session data: " . print_r($_SESSION, true));

    // Check if user is logged in via session
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
        logMessage("User not logged in - session missing or invalid");
        http_response_code(401);
        echo json_encode([
            'status' => 'error',
            'message' => 'Please login first',
            'code' => 'NOT_LOGGED_IN'
        ]);
        exit;
    }

    // Get user ID from session
    $user_id = $_SESSION['user_id'];
    logMessage("User ID from session: " . $user_id);

    // Include database connection
    require_once 'db_connect.php';

    // Get user data from database
    $stmt = $pdo->prepare("
        SELECT 
            user_id, 
            full_name, 
            username, 
            email, 
            phone, 
            role, 
            gender, 
            dob, 
            profile_image,
            account_status,
            created_at
        FROM users 
        WHERE user_id = ? 
        LIMIT 1
    ");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        logMessage("User not found in database: $user_id");
        session_destroy();
        http_response_code(401);
        echo json_encode([
            'status' => 'error',
            'message' => 'User account not found',
            'code' => 'USER_NOT_FOUND'
        ]);
        exit;
    }

    // Check if account is active
    if ($user['account_status'] !== 'active') {
        logMessage("Inactive account: $user_id");
        session_destroy();
        http_response_code(403);
        echo json_encode([
            'status' => 'error',
            'message' => 'Account is ' . $user['account_status'],
            'code' => 'ACCOUNT_INACTIVE'
        ]);
        exit;
    }

    // Update session with fresh data
    $_SESSION['full_name'] = $user['full_name'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['email'] = $user['email'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['phone'] = $user['phone'];
    $_SESSION['gender'] = $user['gender'];
    $_SESSION['dob'] = $user['dob'];
    $_SESSION['profile_image'] = $user['profile_image'] ?? null;

    logMessage("Auth check SUCCESS for: " . $user['username']);

    // Return user data
    echo json_encode([
        'status' => 'success',
        'user' => [
            'id' => (int)$user['user_id'],
            'name' => $user['full_name'],
            'username' => $user['username'],
            'email' => $user['email'],
            'phone' => $user['phone'],
            'role' => $user['role'],
            'gender' => $user['gender'],
            'dob' => $user['dob'],
            'profile_image' => $user['profile_image'] ?? null,
            'account_status' => $user['account_status'],
            'registered' => $user['created_at']
        ]
    ]);
} catch (PDOException $e) {
    logMessage("Database Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Database error occurred',
        'code' => 'DB_ERROR'
    ]);
} catch (Exception $e) {
    logMessage("General Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Server error occurred',
        'code' => 'SERVER_ERROR'
    ]);
}
