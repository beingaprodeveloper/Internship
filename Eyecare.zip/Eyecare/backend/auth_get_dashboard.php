<?php
// backend/auth_get_dashboard.php
header('Content-Type: application/json');

// Enable error reporting for debugging (set to 0 in production)
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized – please log in']);
    exit;
}

require_once 'db_connect.php';

try {
    // --- 1. Specializations ---
    $specStmt = $pdo->query("
        SELECT id, name AS label, icon
        FROM specializations
        ORDER BY name
    ");
    $specializations = $specStmt->fetchAll(PDO::FETCH_ASSOC);

    // --- 2. Treatments for each specialization ---
    $treatStmt = $pdo->prepare("
        SELECT 
            id,
            name,
            description,
            consult_fee,
            duration,
            package_name
        FROM treatments
        WHERE specialization_id = ?
        ORDER BY name
    ");

    foreach ($specializations as &$spec) {
        $treatStmt->execute([$spec['id']]);
        $treatments = $treatStmt->fetchAll(PDO::FETCH_ASSOC);

        // Process each treatment to ensure frontend-compatible fields
        foreach ($treatments as &$t) {
            // consult_fee: ensure numeric (fallback 0)
            $t['consult_fee'] = (float) ($t['consult_fee'] ?? 0);

            // duration: parse first number from string (e.g., "30 Minutes" -> 30)
            $durationString = $t['duration'] ?? '30';
            preg_match('/\d+/', $durationString, $matches);
            $t['duration'] = isset($matches[0]) ? (int) $matches[0] : 30;
            if ($t['duration'] <= 0) $t['duration'] = 30;

            // description: ensure string
            $t['description'] = $t['description'] ?? 'No description available';

            // package_name: may be null
            $t['package_name'] = $t['package_name'] ?? null;
        }
        $spec['treatments'] = $treatments;
    }

    // --- 3. Doctors ---
    $docStmt = $pdo->query("
        SELECT 
            d.id,
            d.name,
            s.name AS specialization,
            d.fee,
            d.available_today AS availableToday,
            d.rating,
            CONCAT(d.experience, ' years') AS experience
        FROM doctors d
        LEFT JOIN specializations s ON d.specialization_id = s.id
        ORDER BY d.name
    ");
    $doctors = $docStmt->fetchAll(PDO::FETCH_ASSOC);

    // Normalize doctor fields
    foreach ($doctors as &$doc) {
        $doc['fee'] = (float) ($doc['fee'] ?? 0);
        $doc['rating'] = (float) ($doc['rating'] ?? 4.5);
        $doc['availableToday'] = (bool) ($doc['availableToday'] ?? true);
        $doc['experience'] = $doc['experience'] ?? '0 years';
        $doc['specialization'] = $doc['specialization'] ?? 'General';
    }

    // --- 4. Return success ---
    echo json_encode([
        'status' => 'success',
        'data' => [
            'specializations' => $specializations,
            'doctors' => $doctors
        ]
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    // Detailed error for debugging (remove in production)
    echo json_encode([
        'status' => 'error',
        'message' => 'Database error: ' . $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Server error: ' . $e->getMessage()
    ]);
}
