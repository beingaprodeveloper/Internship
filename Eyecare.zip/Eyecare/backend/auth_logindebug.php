<?php
// backend/auth_logindebug.php
// Authentication Debug Tool - For testing login flow
// IMPORTANT: Remove or restrict access in production!

session_start();
header('Content-Type: application/json');

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Function to get session status
function getSessionStatus()
{
    return [
        'session_active' => session_status() === PHP_SESSION_ACTIVE,
        'session_id' => session_id(),
        'session_data' => $_SESSION ?? [],
        'session_cookie_params' => session_get_cookie_params()
    ];
}

// Function to test database connection
function testDatabaseConnection($pdo)
{
    try {
        $stmt = $pdo->query("SELECT 1 as test");
        $result = $stmt->fetch();
        return [
            'connected' => true,
            'message' => 'Database connection successful'
        ];
    } catch (PDOException $e) {
        return [
            'connected' => false,
            'message' => $e->getMessage()
        ];
    }
}

// Function to test user authentication
function testUserAuthentication($pdo, $username, $password)
{
    try {
        $stmt = $pdo->prepare("
            SELECT user_id, full_name, username, email, password, role, account_status 
            FROM users 
            WHERE email = ? OR username = ?
            LIMIT 1
        ");
        $stmt->execute([$username, $username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            return [
                'authenticated' => false,
                'message' => 'User not found'
            ];
        }

        if ($user['account_status'] !== 'active') {
            return [
                'authenticated' => false,
                'message' => 'Account is ' . $user['account_status']
            ];
        }

        $passwordValid = password_verify($password, $user['password']);

        return [
            'authenticated' => $passwordValid,
            'user' => [
                'id' => $user['user_id'],
                'full_name' => $user['full_name'],
                'username' => $user['username'],
                'email' => $user['email'],
                'role' => $user['role'],
                'account_status' => $user['account_status']
            ],
            'password_valid' => $passwordValid,
            'message' => $passwordValid ? 'Password verified' : 'Invalid password'
        ];
    } catch (PDOException $e) {
        return [
            'authenticated' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ];
    }
}

// Handle debug actions
$action = $_GET['action'] ?? 'status';
$response = [
    'timestamp' => date('Y-m-d H:i:s'),
    'action' => $action,
    'server' => [
        'php_version' => phpversion(),
        'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown'
    ]
];

try {
    // Include database connection
    require_once 'db_connect.php';

    // Test database connection
    $response['database'] = testDatabaseConnection($pdo);

    // Session status
    $response['session'] = getSessionStatus();

    // Handle specific actions
    switch ($action) {
        case 'test_login':
            // Test login with provided credentials
            $test_username = $_GET['username'] ?? $_POST['username'] ?? '';
            $test_password = $_GET['password'] ?? $_POST['password'] ?? '';

            if (empty($test_username) || empty($test_password)) {
                $response['test_login'] = [
                    'success' => false,
                    'message' => 'Username and password required for test_login action'
                ];
            } else {
                $response['test_login'] = testUserAuthentication($pdo, $test_username, $test_password);
            }
            break;

        case 'check_session':
            // Check if user is logged in
            $response['is_logged_in'] = isset($_SESSION['user_id']);
            if ($response['is_logged_in']) {
                $response['user'] = [
                    'id' => $_SESSION['user_id'],
                    'name' => $_SESSION['full_name'] ?? 'Unknown',
                    'role' => $_SESSION['role'] ?? 'Unknown'
                ];
            }
            break;

        case 'list_users':
            // List all users (for debugging only)
            if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
                $stmt = $pdo->query("
                    SELECT user_id, full_name, username, email, role, account_status, created_at 
                    FROM users 
                    LIMIT 20
                ");
                $response['users'] = $stmt->fetchAll();
            } else {
                $response['users'] = ['message' => 'Admin access required'];
            }
            break;

        case 'clear_session':
            // Clear session
            $_SESSION = array();
            session_destroy();
            $response['session_cleared'] = true;
            $response['session'] = getSessionStatus();
            break;

        case 'status':
        default:
            // Basic status check
            $response['status'] = 'Authentication system is operational';
            $response['database_connected'] = $response['database']['connected'] ?? false;
            $response['session_active'] = $response['session']['session_active'] ?? false;
            break;
    }
} catch (Exception $e) {
    $response['error'] = $e->getMessage();
    $response['trace'] = $e->getTraceAsString();
}

// Output as JSON
echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
