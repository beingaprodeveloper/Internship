<?php
// backend/auth_logout.php
// Handles user logout

session_start();

// Log the logout
if (isset($_SESSION['user_id'])) {
    error_log("LOGOUT: User " . $_SESSION['username'] . " (ID: " . $_SESSION['user_id'] . ") logged out");
}

// Clear all session variables
$_SESSION = array();

// Destroy the session cookie
if (isset($_COOKIE[session_name()])) {
    setcookie(session_name(), '', time() - 3600, '/');
}

// Destroy the session
session_destroy();

// Return JSON response for AJAX logout
header('Content-Type: application/json');
echo json_encode([
    'status' => 'success',
    'message' => 'Logged out successfully',
    'redirect' => '../frontend/login.html'
]);
