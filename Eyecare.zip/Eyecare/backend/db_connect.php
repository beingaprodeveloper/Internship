<?php

/**
 * Database Connection Configuration
 * EyeCare Appointment System
 */
// Project Root
if (!defined('BASE_PATH')) {
    define('BASE_PATH', __DIR__);
}

// Database configuration - Using care_db
define('DB_HOST', 'localhost');
define('DB_NAME', 'care_db');  // ← Changed to your database name
define('DB_USER', 'root');
define('DB_PASS', '');

/**
 * Get database connection using PDO
 * @return PDO
 * @throws PDOException
 */
function getDBConnection()
{
    try {
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
            DB_USER,
            DB_PASS,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
            ]
        );
        return $pdo;
    } catch (PDOException $e) {
        throw new PDOException("Database connection failed: " . $e->getMessage());
    }
}

/**
 * Get MySQLi connection (alternative)
 * @return mysqli
 */
function getMySQLiConnection()
{
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $conn->set_charset("utf8mb4");
    return $conn;
}

// Create a global connection variable for backward compatibility
try {
    $pdo = getDBConnection();
    $conn = getMySQLiConnection();
} catch (Exception $e) {
    // Handle connection error gracefully
    die("Database connection error: " . $e->getMessage());
}

// Test the connection
function testConnection()
{
    global $pdo;
    try {
        $stmt = $pdo->query("SELECT 1");
        return true;
    } catch (PDOException $e) {
        return false;
    }
}

// If this file is accessed directly, test the connection
if (basename($_SERVER['PHP_SELF']) == 'db_connect.php') {
    if (testConnection()) {
        echo "✅ Database connection successful! (care_db)";
    } else {
        echo "❌ Database connection failed! Check your database settings.";
    }
}
