<?php
// backend/login.php
// Start session at the VERY beginning
session_start();
header('Content-Type: application/json');

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Log function for debugging
function logMessage($msg)
{
    error_log("LOGIN: " . $msg);
}

try {
    logMessage("=== LOGIN REQUEST START ===");

    // Check if request method is POST
    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        echo json_encode([
            'status' => 'error',
            'message' => 'Invalid request method. Please use POST.'
        ]);
        exit;
    }

    // Include database connection
    require_once 'db_connect.php';

    // Get and sanitize input
    $user_input = trim($_POST['username_email'] ?? '');
    $password = $_POST['password'] ?? '';
    $remember_me = isset($_POST['remember_me']) ? true : false;

    logMessage("Login attempt for: " . $user_input);

    // Validate input
    if (empty($user_input) || empty($password)) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Please enter both username/email and password.'
        ]);
        exit;
    }

    // Check if input is email or username
    $is_email = filter_var($user_input, FILTER_VALIDATE_EMAIL);

    // Prepare query
    if ($is_email) {
        $sql = "SELECT 
                    user_id, 
                    full_name, 
                    username, 
                    email, 
                    password, 
                    role, 
                    phone, 
                    gender, 
                    dob, 
                    account_status,
                    profile_image,
                    created_at
                FROM users 
                WHERE email = :input
                LIMIT 1";
    } else {
        $sql = "SELECT 
                    user_id, 
                    full_name, 
                    username, 
                    email, 
                    password, 
                    role, 
                    phone, 
                    gender, 
                    dob, 
                    account_status,
                    profile_image,
                    created_at
                FROM users 
                WHERE username = :input
                LIMIT 1";
    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute([':input' => $user_input]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if user exists
    if (!$user) {
        logMessage("User not found: " . $user_input);
        echo json_encode([
            'status' => 'error',
            'message' => 'Invalid credentials.'
        ]);
        exit;
    }

    // Check if account is active
    if ($user['account_status'] !== 'active') {
        logMessage("Inactive account: " . $user_input);
        echo json_encode([
            'status' => 'error',
            'message' => 'Your account is not active. Please contact support.'
        ]);
        exit;
    }

    // Verify password
    if (!password_verify($password, $user['password'])) {
        logMessage("Invalid password for user: " . $user_input);
        echo json_encode([
            'status' => 'error',
            'message' => 'Invalid credentials.'
        ]);
        exit;
    }

    // ========== CREATE SESSION ==========
    logMessage("Creating session for user: " . $user['username']);

    // Regenerate session ID for security
    session_regenerate_id(true);

    // Set ALL session variables
    $_SESSION['user_id'] = (int)$user['user_id'];
    $_SESSION['full_name'] = $user['full_name'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['email'] = $user['email'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['phone'] = $user['phone'];
    $_SESSION['gender'] = $user['gender'];
    $_SESSION['dob'] = $user['dob'];
    $_SESSION['profile_image'] = $user['profile_image'] ?? null;
    $_SESSION['logged_in'] = true;
    $_SESSION['login_time'] = time();

    logMessage("Session created successfully!");
    logMessage("Session data: " . print_r($_SESSION, true));

    // Determine redirect based on role
    $role = strtolower($user['role']);
    $redirect_map = [
        'admin'   => '../frontend/admin/dashboard.html',         // ← NOW POINTS TO PHP
        'doctor'  => '../frontend/doctor/dashboard.html',
        'patient' => '../frontend/patient/home.html'
    ];
    $redirect_url = $redirect_map[$role] ?? '../frontend/patient/home.html';


    // Return success response
    echo json_encode([
        'status' => 'success',
        'message' => 'Login successful!',
        'user' => [
            'id' => (int)$user['user_id'],
            'name' => $user['full_name'],
            'username' => $user['username'],
            'email' => $user['email'],
            'role' => $user['role']
        ],
        'redirect' => $redirect_url
    ]);
} catch (PDOException $e) {
    logMessage("Database Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Database error occurred. Please try again later.'
    ]);
} catch (Exception $e) {
    logMessage("General Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'An error occurred. Please try again later.'
    ]);
}
