<?php

define("MAIL_HOST", "smtp.gmail.com");

define("MAIL_PORT", 587);

define("MAIL_USERNAME", "YOUR_GMAIL@gmail.com");

define("MAIL_PASSWORD", "afab btov mvfs vxar");

define("MAIL_FROM", "YOUR_GMAIL@gmail.com");

define("MAIL_FROM_NAME", "Healthcare Appointment System");
