<?php
// backend/appointment_letter.php
header('Content-Type: text/html; charset=utf-8');
session_start();

// --- Configuration ---
// Clinic / hospital details (you can put these in a config file later)
$clinic = [
    'name'    => 'ClearView Eye Care',
    'address' => '123 Vision Lane, Medical District, City, 10001',
    'phone'   => '+1 (555) 123-4567',
    'email'   => 'info@clearview.eyecare',
    'logo'    => '👁️', // or image URL
];

// --- Check authentication ---
if (!isset($_SESSION['user_id']) || $_SESSION['logged_in'] !== true) {
    die('Unauthorized. Please log in.');
}

require_once 'db_connect.php';

// --- Get booking ID ---
$booking_id = isset($_GET['booking_id']) ? (int)$_GET['booking_id'] : 0;
if (!$booking_id) {
    die('Missing booking ID.');
}

try {
    // Fetch appointment details with patient and doctor info
    $stmt = $pdo->prepare("
        SELECT 
            a.appointment_id,
            a.appointment_date,
            a.start_time,
            a.end_time,
            a.appointment_type,
            a.reason,
            a.status,
            a.booked_at,
            u.full_name AS patient_name,
            u.email AS patient_email,
            u.phone AS patient_phone,
            u.address AS patient_address,
            d.name AS doctor_name,
            d.qualification AS doctor_qualification,
            d.fee AS doctor_fee,
            s.name AS specialization_name
        FROM appointments a
        LEFT JOIN users u ON a.patient_id = u.user_id
        LEFT JOIN doctors d ON a.provider_id = d.id
        LEFT JOIN specializations s ON d.specialization_id = s.id
        WHERE a.appointment_id = ? AND a.patient_id = ?
    ");
    $stmt->execute([$booking_id, $_SESSION['user_id']]);
    $appointment = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$appointment) {
        die('Appointment not found or you do not have permission.');
    }

    // Format date/time
    $dateFormatted = date('l, F j, Y', strtotime($appointment['appointment_date']));
    $timeFormatted = date('g:i A', strtotime($appointment['start_time']));
    $bookedAt = date('F j, Y \a\t g:i A', strtotime($appointment['booked_at']));

    // Build the letter HTML
    $html = '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment Letter</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <style>
        /* ── Reset & Base ── */
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family: "Inter", -apple-system, sans-serif;
            background: #f5f0eb;
            display: flex;
            justify-content: center;
            padding: 40px 20px;
            color: #2c1810;
        }
        .letter-container {
            max-width: 800px;
            width: 100%;
            background: #ffffff;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(44,24,16,0.15);
            overflow: hidden;
            padding: 0;
        }
        .letter-header {
            background: linear-gradient(135deg, #6b1d2a 0%, #8a2a3a 100%);
            color: #fff;
            padding: 32px 40px 24px;
            position: relative;
        }
        .letter-header .clinic-name {
            font-size: 1.8rem;
            font-weight: 700;
            letter-spacing: -0.5px;
        }
        .letter-header .clinic-tagline {
            font-size: 0.9rem;
            opacity: 0.8;
            margin-top: 4px;
        }
        .letter-header .clinic-details {
            font-size: 0.8rem;
            opacity: 0.7;
            margin-top: 8px;
            line-height: 1.4;
        }
        .letter-header .letter-title {
            font-size: 1.2rem;
            font-weight: 600;
            background: rgba(255,255,255,0.12);
            display: inline-block;
            padding: 4px 16px;
            border-radius: 30px;
            margin-top: 12px;
            border: 1px solid rgba(255,255,255,0.15);
        }
        .letter-body {
            padding: 32px 40px 40px;
        }
        .section {
            margin-bottom: 28px;
        }
        .section-title {
            font-size: 0.85rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #6b1d2a;
            border-bottom: 2px solid #e8dfd4;
            padding-bottom: 8px;
            margin-bottom: 14px;
        }
        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px 24px;
        }
        .info-item {
            display: flex;
            flex-direction: column;
        }
        .info-item .label {
            font-size: 0.7rem;
            text-transform: uppercase;
            color: #7a6a5e;
            font-weight: 600;
            letter-spacing: 0.5px;
        }
        .info-item .value {
            font-size: 0.95rem;
            font-weight: 500;
            color: #2c1810;
        }
        .info-item .value.highlight {
            color: #0f7a5a;
            font-weight: 700;
        }
        .status-badge {
            display: inline-block;
            padding: 4px 16px;
            border-radius: 30px;
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            background: #e6f7f0;
            color: #0f7a5a;
        }
        .status-badge.confirmed {
            background: #e6f7f0;
            color: #0f7a5a;
        }
        .status-badge.scheduled {
            background: #fef3e2;
            color: #c9a84c;
        }
        .divider {
            height: 1px;
            background: #e8dfd4;
            margin: 24px 0;
        }
        .footer {
            text-align: center;
            font-size: 0.75rem;
            color: #7a6a5e;
            border-top: 1px solid #e8dfd4;
            padding-top: 20px;
            margin-top: 12px;
        }
        .actions {
            display: flex;
            gap: 12px;
            justify-content: center;
            margin-top: 24px;
            flex-wrap: wrap;
        }
        .btn {
            padding: 12px 28px;
            border-radius: 30px;
            font-weight: 600;
            font-size: 0.9rem;
            border: none;
            cursor: pointer;
            transition: all 0.2s ease;
            font-family: "Inter", sans-serif;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .btn-primary {
            background: #6b1d2a;
            color: #fff;
            box-shadow: 0 4px 16px rgba(107,29,42,0.25);
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(107,29,42,0.3);
        }
        .btn-gold {
            background: #c9a84c;
            color: #2c1810;
            box-shadow: 0 4px 16px rgba(201,168,76,0.3);
        }
        .btn-gold:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(201,168,76,0.4);
        }
        .btn-outline {
            background: transparent;
            border: 2px solid #d5c8b8;
            color: #4a3528;
        }
        .btn-outline:hover {
            background: #f5f0eb;
        }
        .print-only {
            display: none;
        }

        /* ── Print Styles ── */
        @media print {
            body { background: white; padding: 0; }
            .letter-container { box-shadow: none; border-radius: 0; }
            .actions { display: none; }
            .no-print { display: none; }
            .print-only { display: block; }
        }

        @media (max-width: 600px) {
            .letter-header, .letter-body { padding: 24px 20px; }
            .info-grid { grid-template-columns: 1fr; }
            .actions { flex-direction: column; align-items: center; }
            .btn { width: 100%; justify-content: center; }
        }
    </style>
</head>
<body>
    <div class="letter-container">
        <div class="letter-header">
            <div class="clinic-name">' . htmlspecialchars($clinic['name']) . '</div>
            <div class="clinic-tagline">Premium Eye Care Services</div>
            <div class="clinic-details">
                ' . htmlspecialchars($clinic['address']) . '<br>
                ' . htmlspecialchars($clinic['phone']) . ' · ' . htmlspecialchars($clinic['email']) . '
            </div>
            <div class="letter-title">Appointment Confirmation Letter</div>
        </div>

        <div class="letter-body">
            <!-- Patient Section -->
            <div class="section">
                <div class="section-title">Patient Information</div>
                <div class="info-grid">
                    <div class="info-item">
                        <span class="label">Full Name</span>
                        <span class="value">' . htmlspecialchars($appointment['patient_name']) . '</span>
                    </div>
                    <div class="info-item">
                        <span class="label">Email</span>
                        <span class="value">' . htmlspecialchars($appointment['patient_email']) . '</span>
                    </div>
                    <div class="info-item">
                        <span class="label">Phone</span>
                        <span class="value">' . htmlspecialchars($appointment['patient_phone'] ?? 'N/A') . '</span>
                    </div>
                    <div class="info-item">
                        <span class="label">Address</span>
                        <span class="value">' . htmlspecialchars($appointment['patient_address'] ?? 'N/A') . '</span>
                    </div>
                </div>
            </div>

            <!-- Appointment Section -->
            <div class="section">
                <div class="section-title">Appointment Details</div>
                <div class="info-grid">
                    <div class="info-item">
                        <span class="label">Booking ID</span>
                        <span class="value highlight">#' . str_pad($appointment['appointment_id'], 6, '0', STR_PAD_LEFT) . '</span>
                    </div>
                    <div class="info-item">
                        <span class="label">Date</span>
                        <span class="value">' . $dateFormatted . '</span>
                    </div>
                    <div class="info-item">
                        <span class="label">Time</span>
                        <span class="value">' . $timeFormatted . ' – ' . date('g:i A', strtotime($appointment['end_time'])) . '</span>
                    </div>
                    <div class="info-item">
                        <span class="label">Status</span>
                        <span class="status-badge ' . strtolower($appointment['status']) . '">' . ucfirst($appointment['status']) . '</span>
                    </div>
                    <div class="info-item">
                        <span class="label">Appointment Type</span>
                        <span class="value">' . htmlspecialchars($appointment['appointment_type'] ?? 'General') . '</span>
                    </div>
                    <div class="info-item">
                        <span class="label">Reason</span>
                        <span class="value">' . htmlspecialchars($appointment['reason'] ?? 'N/A') . '</span>
                    </div>
                </div>
            </div>

            <!-- Doctor Section -->
            <div class="section">
                <div class="section-title">Doctor Information</div>
                <div class="info-grid">
                    <div class="info-item">
                        <span class="label">Doctor Name</span>
                        <span class="value">' . htmlspecialchars($appointment['doctor_name']) . '</span>
                    </div>
                    <div class="info-item">
                        <span class="label">Specialization</span>
                        <span class="value">' . htmlspecialchars($appointment['specialization_name'] ?? 'General') . '</span>
                    </div>
                    <div class="info-item">
                        <span class="label">Qualification</span>
                        <span class="value">' . htmlspecialchars($appointment['doctor_qualification'] ?? 'N/A') . '</span>
                    </div>
                    <div class="info-item">
                        <span class="label">Consultation Fee</span>
                        <span class="value">$' . number_format($appointment['doctor_fee'] ?? 0, 2) . '</span>
                    </div>
                </div>
            </div>

            <div class="divider"></div>

            <!-- Confirmation & Notes -->
            <div style="background: #f8f2e9; padding: 16px 20px; border-radius: 12px; border-left: 4px solid #c9a84c;">
                <p style="font-weight: 600; font-size: 0.9rem; color: #2c1810;">✅ Booking Confirmed</p>
                <p style="font-size: 0.85rem; color: #4a3528; margin-top: 4px;">
                    This appointment has been confirmed. Please arrive 15 minutes early. 
                    Bring any previous medical records and a valid ID.
                </p>
                <p style="font-size: 0.75rem; color: #7a6a5e; margin-top: 8px;">
                    Booked on: ' . $bookedAt . '
                </p>
            </div>

            <div class="footer">
                This is a computer-generated document. No signature is required.
                <br>© ' . date('Y') . ' ' . htmlspecialchars($clinic['name']) . '. All rights reserved.
            </div>
        </div>
    </div>

    <!-- Actions (visible on screen, hidden when printing) -->
    <div style="text-align:center; max-width:800px; margin: 20px auto 0; padding: 0 20px;" class="no-print">
        <div class="actions">
            <button onclick="window.print()" class="btn btn-gold">
                <i class="fas fa-print"></i> Print / Download PDF
            </button>
            <button onclick="window.close()" class="btn btn-outline">
                <i class="fas fa-times"></i> Close
            </button>
        </div>
        <p style="font-size:0.75rem; color:#7a6a5e; margin-top:12px;">
            <i class="fas fa-info-circle"></i> Use "Print" to save as PDF or print a hard copy.
        </p>
    </div>

    <script>
        // Auto-print? We'll not do auto; user clicks the button.
        // But we can add a small help.
        console.log("Appointment letter loaded.");
    </script>
</body>
</html>';

    echo $html;

} catch (Exception $e) {
    http_response_code(500);
    echo '<h1>Error</h1><p>Unable to generate letter. Please try again later.</p>';
    error_log('appointment_letter.php error: ' . $e->getMessage());
}