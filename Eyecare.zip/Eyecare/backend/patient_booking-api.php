<?php
// backend/patient_booking-api.php
// Handles all appointment operations: GET (list), POST (book), PUT (cancel/update)

header('Content-Type: application/json');
session_start();

require_once 'db_connect.php';

// Authenticate user
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized – please log in']);
    exit;
}

$user_id = $_SESSION['user_id'];
$method = $_SERVER['REQUEST_METHOD'];

try {
    switch ($method) {
        // ------------------------------------------------
        // GET  – Fetch patient's appointments
        // ------------------------------------------------
        case 'GET':
            $stmt = $pdo->prepare("
                SELECT 
                    a.appointment_id,
                    a.appointment_date,
                    a.start_time,
                    a.end_time,
                    a.appointment_type,
                    a.reason,
                    a.status,
                    a.booked_at,
                    d.name AS doctor_name,
                    d.photo AS doctor_photo,
                    s.name AS specialization_name
                FROM appointments a
                LEFT JOIN doctors d ON a.provider_id = d.id
                LEFT JOIN specializations s ON d.specialization_id = s.id
                WHERE a.patient_id = ?
                ORDER BY a.appointment_date DESC, a.start_time DESC
            ");
            $stmt->execute([$user_id]);
            $appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);

            echo json_encode([
                'status' => 'success',
                'data' => $appointments
            ]);
            break;

        // ------------------------------------------------
        // POST – Create a new appointment
        // ------------------------------------------------
        case 'POST':
            $data = json_decode(file_get_contents('php://input'), true);
            if (!$data) {
                http_response_code(400);
                echo json_encode(['status' => 'error', 'message' => 'Invalid JSON payload']);
                exit;
            }

            // Required fields (matches frontend)
            $required = ['provider_id', 'appointment_date', 'start_time'];
            foreach ($required as $field) {
                if (empty($data[$field])) {
                    http_response_code(400);
                    echo json_encode(['status' => 'error', 'message' => "Missing required field: $field"]);
                    exit;
                }
            }

            // Extract values with defaults
            $provider_id      = (int)$data['provider_id'];
            $appointment_date = $data['appointment_date'];
            $start_time       = $data['start_time'];
            $end_time         = $data['end_time'] ?? null;
            $appointment_type = $data['appointment_type'] ?? 'General Checkup';
            $reason           = $data['reason'] ?? null;
            $is_premium       = !empty($data['is_premium']);
            $service_id       = $data['service_id'] ?? null;
            $service_name     = $data['service_name'] ?? null;

            // Check if the slot is still available
            $stmt = $pdo->prepare("
                SELECT COUNT(*) FROM appointments 
                WHERE provider_id = ? 
                  AND appointment_date = ? 
                  AND start_time = ? 
                  AND status NOT IN ('cancelled', 'completed')
            ");
            $stmt->execute([$provider_id, $appointment_date, $start_time]);
            $existing = $stmt->fetchColumn();

            if ($existing > 0) {
                http_response_code(409);
                echo json_encode(['status' => 'error', 'message' => 'This time slot is already booked']);
                exit;
            }

            // Calculate end time if not provided (default 30 minutes)
            if (!$end_time) {
                $dt = new DateTime($start_time);
                $dt->add(new DateInterval('PT30M'));
                $end_time = $dt->format('H:i:s');
            }

            // --- Insert appointment (main table) ---
            $stmt = $pdo->prepare("
                INSERT INTO appointments 
                (patient_id, provider_id, appointment_date, start_time, end_time, appointment_type, reason, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, 'scheduled')
            ");
            $result = $stmt->execute([
                $user_id,
                $provider_id,
                $appointment_date,
                $start_time,
                $end_time,
                $appointment_type,
                $reason
            ]);

            if (!$result) {
                // Capture the exact SQL error
                $errorInfo = $stmt->errorInfo();
                http_response_code(500);
                echo json_encode([
                    'status' => 'error',
                    'message' => 'Database insert failed: ' . ($errorInfo[2] ?? 'unknown error')
                ]);
                exit;
            }

            $appointment_id = $pdo->lastInsertId();

            // If premium, also create a record in premium_bookings
            if ($is_premium) {
                $booking_ref = 'PB-' . date('Ymd') . '-' . strtoupper(substr(md5(uniqid()), 0, 6));
                $stmt = $pdo->prepare("
                    INSERT INTO premium_bookings 
                    (booking_reference, patient_id, provider_id, service_id, service_name, 
                     appointment_date, appointment_time, duration, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')
                ");
                $result = $stmt->execute([
                    $booking_ref,
                    $user_id,
                    $provider_id,
                    $service_id ?: 'general',
                    $service_name ?: 'General Consultation',
                    $appointment_date,
                    $start_time,
                    '30 mins'
                ]);
                // If premium insert fails, we log but still consider booking successful
                if (!$result) {
                    error_log("Premium booking insert failed for appointment ID $appointment_id: " . print_r($stmt->errorInfo(), true));
                }
            }

            // Success response (matches frontend expectation)
            echo json_encode([
                'status' => 'success',
                'message' => 'Appointment booked successfully',
                'appointment_id' => $appointment_id,
                'booking_reference' => $booking_ref ?? null
            ]);
            break;

        // ------------------------------------------------
        // PUT – Update appointment (e.g., cancel)
        // ------------------------------------------------
        case 'PUT':
            $data = json_decode(file_get_contents('php://input'), true);
            if (!$data) {
                http_response_code(400);
                echo json_encode(['status' => 'error', 'message' => 'Invalid JSON payload']);
                exit;
            }

            $appointment_id = $data['appointment_id'] ?? null;
            $status         = $data['status'] ?? null;
            $cancel_reason  = $data['cancellation_reason'] ?? null;

            if (!$appointment_id || !$status) {
                http_response_code(400);
                echo json_encode(['status' => 'error', 'message' => 'Missing appointment_id or status']);
                exit;
            }

            $stmt = $pdo->prepare("
                UPDATE appointments 
                SET status = ?, cancellation_reason = ?
                WHERE appointment_id = ? AND patient_id = ?
            ");
            $result = $stmt->execute([$status, $cancel_reason, $appointment_id, $user_id]);

            if ($result && $stmt->rowCount() > 0) {
                echo json_encode([
                    'status' => 'success',
                    'message' => 'Appointment updated successfully'
                ]);
            } else {
                http_response_code(404);
                echo json_encode([
                    'status' => 'error',
                    'message' => 'Appointment not found or no changes made'
                ]);
            }
            break;

        default:
            http_response_code(405);
            echo json_encode(['status' => 'error', 'message' => 'Method not allowed']);
            break;
    }
} catch (PDOException $e) {
    error_log("Booking API PDO Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    error_log("Booking API General Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Server error: ' . $e->getMessage()
    ]);
}
