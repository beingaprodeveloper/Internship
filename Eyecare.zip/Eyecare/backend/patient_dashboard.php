<?php
// backend/patient_dashabord.php
header('Content-Type: application/json');
session_start();

require_once 'db_connect.php';

// Authenticate user
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    // ── User details ──
    $stmt = $pdo->prepare("
        SELECT full_name, email, phone, gender, dob, profile_image
        FROM users WHERE user_id = ?
    ");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        http_response_code(404);
        echo json_encode(['status' => 'error', 'message' => 'User not found']);
        exit;
    }

    // ── Statistics ──
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status IN ('scheduled','confirmed') THEN 1 ELSE 0 END) as upcoming_count,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
            SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled,
            -- rx_count: we don't have a prescriptions table, set to 0 (or add later)
            0 as rx_count
        FROM appointments
        WHERE patient_id = ?
    ");
    $stmt->execute([$user_id]);
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);

    // ── Last visit (most recent completed) ──
    $stmt = $pdo->prepare("
        SELECT appointment_date
        FROM appointments
        WHERE patient_id = ? AND status = 'completed'
        ORDER BY appointment_date DESC
        LIMIT 1
    ");
    $stmt->execute([$user_id]);
    $lastVisit = $stmt->fetchColumn();

    // ── Next appointment (soonest upcoming) ──
    $stmt = $pdo->prepare("
        SELECT 
            a.appointment_date,
            a.start_time,
            a.appointment_type as type,
            d.name as provider_name
        FROM appointments a
        LEFT JOIN doctors d ON a.provider_id = d.id
        WHERE a.patient_id = ? 
          AND a.appointment_date >= CURDATE()
          AND a.status NOT IN ('cancelled','completed','no-show')
        ORDER BY a.appointment_date ASC, a.start_time ASC
        LIMIT 1
    ");
    $stmt->execute([$user_id]);
    $nextAppt = $stmt->fetch(PDO::FETCH_ASSOC);

    // ── Recent appointments (last 5) ──
    $stmt = $pdo->prepare("
        SELECT 
            a.appointment_date,
            a.start_time,
            d.name as provider_name,
            a.appointment_type as type,
            a.status
        FROM appointments a
        LEFT JOIN doctors d ON a.provider_id = d.id
        WHERE a.patient_id = ?
        ORDER BY a.appointment_date DESC, a.start_time DESC
        LIMIT 5
    ");
    $stmt->execute([$user_id]);
    $recent = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // ── Response (flat structure, no 'data' wrapper) ──
    echo json_encode([
        'status' => 'success',
        'user' => $user,
        'stats' => [
            'total' => (int)($stats['total'] ?? 0),
            'upcoming_count' => (int)($stats['upcoming_count'] ?? 0),
            'rx_count' => (int)($stats['rx_count'] ?? 0)   // can be updated later
        ],
        'last_visit' => $lastVisit ?: null,
        'next_appointment' => $nextAppt ?: null,
        'recent_appointments' => $recent
    ]);
} catch (PDOException $e) {
    error_log("Patient Dashboard Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Database error – please try again later']);
}
