<?php
// backend/get_slots.php - Debug Version
header('Content-Type: application/json');

// Show errors for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

$doctor_id = isset($_GET['doctor_id']) ? (int)$_GET['doctor_id'] : 0;
$date = isset($_GET['date']) ? $_GET['date'] : '';

if (!$doctor_id || !$date) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Missing doctor_id or date']);
    exit;
}

require_once 'db_connect.php';

try {
    // Get the day of the week
    $dayOfWeek = date('l', strtotime($date));

    // Fetch availability records for this doctor on this day
    $stmt = $pdo->prepare("
        SELECT start_time, end_time, slot_duration
        FROM availabilities
        WHERE provider_id = ? AND day_of_week = ? AND is_available = 1
        ORDER BY start_time
    ");
    $stmt->execute([$doctor_id, $dayOfWeek]);
    $availabilities = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // If no availability records, use a fallback schedule (for testing)
    if (empty($availabilities)) {
        // Default: morning surgery block 8-12, afternoon consult 15-19
        $availabilities = [
            ['start_time' => '08:00:00', 'end_time' => '12:00:00', 'slot_duration' => 30],
            ['start_time' => '15:00:00', 'end_time' => '19:00:00', 'slot_duration' => 20],
        ];
    }

    // Generate all possible slots from the blocks
    $allSlots = [];
    foreach ($availabilities as $block) {
        $start = new DateTime($block['start_time']);
        $end   = new DateTime($block['end_time']);
        $duration = (int)($block['slot_duration'] ?? 30);

        while ($start < $end) {
            $allSlots[] = $start->format('H:i');
            $start->modify("+{$duration} minutes");
        }
    }

    // Fetch booked slots for this doctor on this date
    $stmt = $pdo->prepare("
        SELECT start_time
        FROM appointments
        WHERE provider_id = ? AND appointment_date = ? AND status NOT IN ('cancelled', 'completed')
    ");
    $stmt->execute([$doctor_id, $date]);
    $booked = $stmt->fetchAll(PDO::FETCH_COLUMN);

    // Build response
    $slots = array_map(function ($time) use ($booked) {
        return [
            'time' => $time,
            'booked' => in_array($time . ':00', $booked) // booked times are stored with seconds
        ];
    }, $allSlots);

    echo json_encode([
        'status' => 'success',
        'data' => $slots,
        'debug' => [   // extra info for debugging
            'availabilities_used' => $availabilities,
            'slots_generated' => count($slots)
        ]
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Server error: ' . $e->getMessage()
    ]);
}
