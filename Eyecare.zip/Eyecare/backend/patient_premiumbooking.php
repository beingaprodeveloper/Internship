<?php

/**
 * Premium Booking API Endpoint
 * EyeCare Appointment System - Premium Booking Backend
 * 
 * This API handles all premium booking operations:
 * - Create new premium bookings
 * - Fetch user's premium bookings
 * - Cancel premium bookings
 * - Check availability
 * 
 * Database: MySQL
 * Table: premium_bookings
 */

// ──────────────────────────────────────────────
// CONFIGURATION & DATABASE CONNECTION
// ──────────────────────────────────────────────

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Database configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'eyecare_db');
define('DB_USER', 'root');
define('DB_PASS', '');

// ──────────────────────────────────────────────
// DATABASE CONNECTION
// ──────────────────────────────────────────────

function getDBConnection()
{
    try {
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
            DB_USER,
            DB_PASS,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false
            ]
        );
        return $pdo;
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Database connection failed: ' . $e->getMessage()
        ]);
        exit();
    }
}

// ──────────────────────────────────────────────
// HELPER FUNCTIONS
// ──────────────────────────────────────────────

function validateDate($date)
{
    $d = DateTime::createFromFormat('Y-m-d', $date);
    return $d && $d->format('Y-m-d') === $date;
}

function validateTime($time)
{
    return preg_match('/^(0?[1-9]|1[0-2]):[0-5][0-9] (AM|PM)$/', $time);
}

function convertTo24Hour($time)
{
    $datetime = DateTime::createFromFormat('g:i A', $time);
    return $datetime ? $datetime->format('H:i:s') : null;
}

function generateBookingId()
{
    return 'PB-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));
}

function sanitizeInput($input)
{
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}

// ──────────────────────────────────────────────
// DATABASE TABLE SCHEMA (Create if not exists)
// ──────────────────────────────────────────────

function ensurePremiumBookingsTable()
{
    $pdo = getDBConnection();

    $sql = "
        CREATE TABLE IF NOT EXISTS premium_bookings (
            premium_booking_id INT AUTO_INCREMENT PRIMARY KEY,
            booking_reference VARCHAR(50) UNIQUE NOT NULL,
            patient_id INT NOT NULL,
            provider_id INT,
            service_id VARCHAR(50) NOT NULL,
            service_name VARCHAR(100) NOT NULL,
            appointment_date DATE NOT NULL,
            appointment_time TIME NOT NULL,
            duration VARCHAR(20),
            contact_info VARCHAR(255),
            status ENUM('pending', 'confirmed', 'cancelled', 'completed') DEFAULT 'pending',
            booking_metadata JSON,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            
            INDEX idx_patient_id (patient_id),
            INDEX idx_provider_id (provider_id),
            INDEX idx_status (status),
            INDEX idx_appointment_date (appointment_date),
            INDEX idx_booking_reference (booking_reference),
            
            FOREIGN KEY (patient_id) REFERENCES users(user_id) ON DELETE CASCADE,
            FOREIGN KEY (provider_id) REFERENCES doctors(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ";

    try {
        $pdo->exec($sql);
    } catch (PDOException $e) {
        // Table might already exist or other issue - continue
    }
}

// Ensure table exists on script load
ensurePremiumBookingsTable();

// ──────────────────────────────────────────────
// API ROUTE HANDLER
// ──────────────────────────────────────────────

$method = $_SERVER['REQUEST_METHOD'];
$action = isset($_GET['action']) ? $_GET['action'] : '';

try {
    switch ($method) {
        case 'GET':
            handleGET($action);
            break;
        case 'POST':
            handlePOST($action);
            break;
        case 'PUT':
            handlePUT($action);
            break;
        case 'DELETE':
            handleDELETE($action);
            break;
        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'message' => 'Method not allowed']);
            break;
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Server error: ' . $e->getMessage()
    ]);
}

// ──────────────────────────────────────────────
// GET HANDLER
// ──────────────────────────────────────────────

function handleGET($action)
{
    $pdo = getDBConnection();

    switch ($action) {
        case 'list':
            // Get all premium bookings for a patient
            $patientId = isset($_GET['patient_id']) ? (int)$_GET['patient_id'] : 0;

            if ($patientId <= 0) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Patient ID is required']);
                return;
            }

            $stmt = $pdo->prepare("
                SELECT 
                    pb.*,
                    u.full_name as patient_name,
                    d.name as provider_name,
                    d.specialization_id,
                    s.name as specialization_name
                FROM premium_bookings pb
                LEFT JOIN users u ON pb.patient_id = u.user_id
                LEFT JOIN doctors d ON pb.provider_id = d.id
                LEFT JOIN specializations s ON d.specialization_id = s.id
                WHERE pb.patient_id = ?
                ORDER BY pb.appointment_date DESC, pb.appointment_time DESC
            ");
            $stmt->execute([$patientId]);
            $bookings = $stmt->fetchAll();

            // Format time for display
            foreach ($bookings as &$booking) {
                if ($booking['appointment_time']) {
                    $time = DateTime::createFromFormat('H:i:s', $booking['appointment_time']);
                    $booking['appointment_time_formatted'] = $time ? $time->format('g:i A') : $booking['appointment_time'];
                }
            }

            echo json_encode([
                'success' => true,
                'data' => $bookings,
                'count' => count($bookings)
            ]);
            break;

        case 'details':
            // Get specific booking details
            $bookingId = isset($_GET['booking_id']) ? (int)$_GET['booking_id'] : 0;

            if ($bookingId <= 0) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Booking ID is required']);
                return;
            }

            $stmt = $pdo->prepare("
                SELECT 
                    pb.*,
                    u.full_name as patient_name,
                    u.email as patient_email,
                    u.phone as patient_phone,
                    d.name as provider_name
                FROM premium_bookings pb
                LEFT JOIN users u ON pb.patient_id = u.user_id
                LEFT JOIN doctors d ON pb.provider_id = d.id
                WHERE pb.premium_booking_id = ?
            ");
            $stmt->execute([$bookingId]);
            $booking = $stmt->fetch();

            if (!$booking) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Booking not found']);
                return;
            }

            echo json_encode([
                'success' => true,
                'data' => $booking
            ]);
            break;

        case 'check-availability':
            // Check availability for a specific date/time
            $date = isset($_GET['date']) ? $_GET['date'] : '';
            $time = isset($_GET['time']) ? $_GET['time'] : '';

            if (!validateDate($date)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Invalid date format']);
                return;
            }

            $time24 = null;
            if ($time) {
                if (!validateTime($time)) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'message' => 'Invalid time format']);
                    return;
                }
                $time24 = convertTo24Hour($time);
            }

            $sql = "SELECT COUNT(*) as booked_count FROM premium_bookings 
                    WHERE appointment_date = ? AND status IN ('pending', 'confirmed')";
            $params = [$date];

            if ($time24) {
                $sql .= " AND appointment_time = ?";
                $params[] = $time24;
            }

            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $result = $stmt->fetch();

            echo json_encode([
                'success' => true,
                'date' => $date,
                'time' => $time,
                'booked_count' => (int)$result['booked_count'],
                'available' => (int)$result['booked_count'] < 12 // Max 12 slots per day
            ]);
            break;

        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Invalid action for GET']);
            break;
    }
}

// ──────────────────────────────────────────────
// POST HANDLER (Create Booking)
// ──────────────────────────────────────────────

function handlePOST($action)
{
    $pdo = getDBConnection();

    switch ($action) {
        case 'create':
            // Create a new premium booking
            $input = json_decode(file_get_contents('php://input'), true);

            if (!$input) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Invalid JSON input']);
                return;
            }

            // Validate required fields
            $required = ['patient_id', 'service_id', 'service_name', 'appointment_date', 'appointment_time'];
            foreach ($required as $field) {
                if (!isset($input[$field]) || empty($input[$field])) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'message' => "Missing required field: $field"]);
                    return;
                }
            }

            // Validate date
            if (!validateDate($input['appointment_date'])) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Invalid appointment date format']);
                return;
            }

            // Validate time
            if (!validateTime($input['appointment_time'])) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Invalid appointment time format']);
                return;
            }

            // Check if patient exists
            $stmt = $pdo->prepare("SELECT user_id FROM users WHERE user_id = ?");
            $stmt->execute([$input['patient_id']]);
            if (!$stmt->fetch()) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Patient not found']);
                return;
            }

            // Check if provider exists (if provided)
            if (isset($input['provider_id']) && $input['provider_id'] > 0) {
                $stmt = $pdo->prepare("SELECT id FROM doctors WHERE id = ?");
                $stmt->execute([$input['provider_id']]);
                if (!$stmt->fetch()) {
                    http_response_code(404);
                    echo json_encode(['success' => false, 'message' => 'Provider not found']);
                    return;
                }
            }

            // Check for duplicate booking (same patient, date, time)
            $time24 = convertTo24Hour($input['appointment_time']);
            $stmt = $pdo->prepare("
                SELECT COUNT(*) as count 
                FROM premium_bookings 
                WHERE patient_id = ? 
                AND appointment_date = ? 
                AND appointment_time = ? 
                AND status IN ('pending', 'confirmed')
            ");
            $stmt->execute([$input['patient_id'], $input['appointment_date'], $time24]);
            $result = $stmt->fetch();

            if ($result['count'] > 0) {
                http_response_code(409);
                echo json_encode(['success' => false, 'message' => 'You already have a booking for this date and time']);
                return;
            }

            // Generate booking reference
            $bookingRef = generateBookingId();

            // Prepare metadata
            $metadata = [];
            if (isset($input['duration'])) $metadata['duration'] = $input['duration'];
            if (isset($input['notes'])) $metadata['notes'] = $input['notes'];
            if (isset($input['reminder_contact'])) $metadata['reminder_contact'] = $input['reminder_contact'];

            // Insert booking
            $sql = "
                INSERT INTO premium_bookings (
                    booking_reference,
                    patient_id,
                    provider_id,
                    service_id,
                    service_name,
                    appointment_date,
                    appointment_time,
                    duration,
                    contact_info,
                    booking_metadata,
                    status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ";

            $duration = isset($input['duration']) ? $input['duration'] : '30 mins';
            $contactInfo = isset($input['contact_info']) ? $input['contact_info'] : '';

            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $bookingRef,
                $input['patient_id'],
                isset($input['provider_id']) ? $input['provider_id'] : null,
                $input['service_id'],
                $input['service_name'],
                $input['appointment_date'],
                $time24,
                $duration,
                $contactInfo,
                json_encode($metadata),
                'pending'
            ]);

            $bookingId = $pdo->lastInsertId();

            // Fetch the created booking
            $stmt = $pdo->prepare("
                SELECT * FROM premium_bookings WHERE premium_booking_id = ?
            ");
            $stmt->execute([$bookingId]);
            $booking = $stmt->fetch();

            echo json_encode([
                'success' => true,
                'message' => 'Premium booking created successfully',
                'data' => $booking
            ]);
            break;

        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Invalid action for POST']);
            break;
    }
}

// ──────────────────────────────────────────────
// PUT HANDLER (Update Booking)
// ──────────────────────────────────────────────

function handlePUT($action)
{
    $pdo = getDBConnection();

    switch ($action) {
        case 'update':
            // Update an existing booking
            $input = json_decode(file_get_contents('php://input'), true);

            if (!$input || !isset($input['booking_id'])) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Booking ID is required']);
                return;
            }

            $bookingId = (int)$input['booking_id'];

            // Check if booking exists
            $stmt = $pdo->prepare("SELECT * FROM premium_bookings WHERE premium_booking_id = ?");
            $stmt->execute([$bookingId]);
            $existing = $stmt->fetch();

            if (!$existing) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Booking not found']);
                return;
            }

            // Build update query dynamically
            $updateFields = [];
            $params = [];

            $allowedFields = ['provider_id', 'service_id', 'service_name', 'appointment_date', 'appointment_time', 'duration', 'contact_info', 'status'];

            foreach ($allowedFields as $field) {
                if (isset($input[$field]) && $input[$field] !== null) {
                    if ($field === 'appointment_date' && !validateDate($input[$field])) {
                        http_response_code(400);
                        echo json_encode(['success' => false, 'message' => 'Invalid date format']);
                        return;
                    }
                    if ($field === 'appointment_time' && !validateTime($input[$field])) {
                        http_response_code(400);
                        echo json_encode(['success' => false, 'message' => 'Invalid time format']);
                        return;
                    }

                    if ($field === 'appointment_time') {
                        $input[$field] = convertTo24Hour($input[$field]);
                    }

                    $updateFields[] = "$field = ?";
                    $params[] = $input[$field];
                }
            }

            // Handle metadata updates
            if (isset($input['metadata']) && is_array($input['metadata'])) {
                $existingMetadata = json_decode($existing['booking_metadata'], true) ?: [];
                $mergedMetadata = array_merge($existingMetadata, $input['metadata']);
                $updateFields[] = "booking_metadata = ?";
                $params[] = json_encode($mergedMetadata);
            }

            if (empty($updateFields)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'No fields to update']);
                return;
            }

            $params[] = $bookingId;
            $sql = "UPDATE premium_bookings SET " . implode(', ', $updateFields) . " WHERE premium_booking_id = ?";

            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);

            // Fetch updated booking
            $stmt = $pdo->prepare("SELECT * FROM premium_bookings WHERE premium_booking_id = ?");
            $stmt->execute([$bookingId]);
            $updated = $stmt->fetch();

            echo json_encode([
                'success' => true,
                'message' => 'Booking updated successfully',
                'data' => $updated
            ]);
            break;

        case 'cancel':
            // Cancel a booking
            $input = json_decode(file_get_contents('php://input'), true);

            if (!$input || !isset($input['booking_id'])) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Booking ID is required']);
                return;
            }

            $bookingId = (int)$input['booking_id'];
            $reason = isset($input['cancellation_reason']) ? $input['cancellation_reason'] : 'Cancelled by user';

            // Check if booking exists and is not already cancelled
            $stmt = $pdo->prepare("
                SELECT * FROM premium_bookings 
                WHERE premium_booking_id = ? AND status != 'cancelled'
            ");
            $stmt->execute([$bookingId]);
            $booking = $stmt->fetch();

            if (!$booking) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Booking not found or already cancelled']);
                return;
            }

            // Update status
            $stmt = $pdo->prepare("
                UPDATE premium_bookings 
                SET status = 'cancelled', 
                    booking_metadata = JSON_SET(
                        COALESCE(booking_metadata, '{}'), 
                        '$.cancellation_reason', ?,
                        '$.cancelled_at', ?
                    )
                WHERE premium_booking_id = ?
            ");
            $stmt->execute([
                $reason,
                date('Y-m-d H:i:s'),
                $bookingId
            ]);

            echo json_encode([
                'success' => true,
                'message' => 'Booking cancelled successfully'
            ]);
            break;

        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Invalid action for PUT']);
            break;
    }
}

// ──────────────────────────────────────────────
// DELETE HANDLER
// ──────────────────────────────────────────────

function handleDELETE($action)
{
    $pdo = getDBConnection();

    switch ($action) {
        case 'delete':
            // Permanently delete a booking (admin only)
            $bookingId = isset($_GET['booking_id']) ? (int)$_GET['booking_id'] : 0;

            if ($bookingId <= 0) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Booking ID is required']);
                return;
            }

            // Check if booking exists
            $stmt = $pdo->prepare("SELECT * FROM premium_bookings WHERE premium_booking_id = ?");
            $stmt->execute([$bookingId]);
            if (!$stmt->fetch()) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Booking not found']);
                return;
            }

            $stmt = $pdo->prepare("DELETE FROM premium_bookings WHERE premium_booking_id = ?");
            $stmt->execute([$bookingId]);

            echo json_encode([
                'success' => true,
                'message' => 'Booking deleted successfully'
            ]);
            break;

        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Invalid action for DELETE']);
            break;
    }
}

// ──────────────────────────────────────────────
// ERROR HANDLING
// ──────────────────────────────────────────────

function handleError($errno, $errstr, $errfile, $errline)
{
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Internal server error',
        'debug' => $errstr . ' in ' . $errfile . ':' . $errline
    ]);
    exit();
}

set_error_handler('handleError');
