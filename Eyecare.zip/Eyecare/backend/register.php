<?php
// backend/register.php
header('Content-Type: application/json');
require_once 'db_connect.php';

// Enable error reporting for debugging (remove in production)
error_reporting(E_ALL);
ini_set('display_errors', 0);

// Log function for debugging
function logMessage($msg)
{
    error_log("REGISTER: " . $msg);
}

try {
    // Check if request method is POST
    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
        exit;
    }

    // Get and sanitize input
    $full_name = trim($_POST['full_name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $gender = trim($_POST['gender'] ?? '');
    $dob = trim($_POST['dob'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    logMessage("Processing registration for: $email, $username");

    // ========== SERVER-SIDE VALIDATION ==========

    // 1. Check all required fields
    $required_fields = ['full_name', 'username', 'email', 'phone', 'gender', 'dob', 'password', 'confirm_password'];
    foreach ($required_fields as $field) {
        if (empty($_POST[$field])) {
            echo json_encode(['status' => 'error', 'message' => 'All fields are required. Please fill in all fields.']);
            exit;
        }
    }

    // 2. Validate Full Name (2-100 chars, letters, spaces, hyphens, apostrophes)
    if (!preg_match('/^[a-zA-Z\s\-]{2,100}$/', $full_name)) {
        echo json_encode(['status' => 'error', 'message' => 'Please enter a valid full name (2-100 characters, letters only).']);
        exit;
    }

    // 3. Validate Username (alphanumeric, underscore, 3-50 chars)
    if (!preg_match('/^[a-zA-Z0-9_]{3,50}$/', $username)) {
        echo json_encode(['status' => 'error', 'message' => 'Username must be 3-50 characters and contain only letters, numbers, and underscores.']);
        exit;
    }

    // 4. Validate Email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['status' => 'error', 'message' => 'Please enter a valid email address.']);
        exit;
    }

    // 5. Validate Phone (7-20 chars, numbers, +, -, spaces, parentheses)
    if (!preg_match('/^[0-9+\-\s()]{7,20}$/', $phone)) {
        echo json_encode(['status' => 'error', 'message' => 'Please enter a valid phone number (7-20 characters, numbers and + - ( ) only).']);
        exit;
    }

    // 6. Validate Gender
    $valid_genders = ['Male', 'Female', 'Other'];
    if (!in_array($gender, $valid_genders)) {
        echo json_encode(['status' => 'error', 'message' => 'Please select a valid gender.']);
        exit;
    }

    // 7. Validate Date of Birth (must be at least 10 years old)
    $dobDate = DateTime::createFromFormat('Y-m-d', $dob);
    if (!$dobDate) {
        echo json_encode(['status' => 'error', 'message' => 'Please enter a valid date of birth.']);
        exit;
    }

    $today = new DateTime();
    $age = $today->diff($dobDate)->y;

    if ($age < 10) {
        echo json_encode(['status' => 'error', 'message' => 'You must be at least 10 years old to register.']);
        exit;
    }
    if ($age > 120) {
        echo json_encode(['status' => 'error', 'message' => 'Please enter a valid date of birth.']);
        exit;
    }

    // 8. Validate Password Strength
    $password_errors = [];
    if (strlen($password) < 8) {
        $password_errors[] = 'at least 8 characters long';
    }
    if (!preg_match('/[A-Z]/', $password)) {
        $password_errors[] = 'at least one uppercase letter';
    }
    if (!preg_match('/[a-z]/', $password)) {
        $password_errors[] = 'at least one lowercase letter';
    }
    if (!preg_match('/[0-9]/', $password)) {
        $password_errors[] = 'at least one number';
    }
    if (!preg_match('/[!@#$%^&*(),.?":{}|<>]/', $password)) {
        $password_errors[] = 'at least one special character';
    }

    if (!empty($password_errors)) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Password requirements: ' . implode(', ', $password_errors)
        ]);
        exit;
    }

    // 9. Validate Password Match
    if ($password !== $confirm_password) {
        echo json_encode(['status' => 'error', 'message' => 'Passwords do not match. Please try again.']);
        exit;
    }

    // ========== CHECK FOR EXISTING USERNAME ==========
    // IMPORTANT: This check ensures we don't create duplicate usernames

    // Check if username already exists
    $stmt = $pdo->prepare("SELECT user_id, username FROM users WHERE username = :username");
    $stmt->execute([':username' => $username]);
    $existingUser = $stmt->fetch();

    if ($existingUser) {
        logMessage("Username already taken: $username");
        echo json_encode(['status' => 'error', 'message' => 'Username already taken. Please choose a different username.']);
        exit;
    }

    // Check if email already exists
    $stmt = $pdo->prepare("SELECT user_id, email FROM users WHERE email = :email");
    $stmt->execute([':email' => $email]);
    $existingEmail = $stmt->fetch();

    if ($existingEmail) {
        logMessage("Email already registered: $email");
        echo json_encode(['status' => 'error', 'message' => 'Email already registered. Please use a different email address.']);
        exit;
    }

    // ========== HASH PASSWORD & INSERT USER ==========

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    logMessage("Password hashed successfully for: $username");

    // Begin transaction
    $pdo->beginTransaction();

    try {
        // Insert new user into users table
        $sql = "INSERT INTO users (
                    full_name, 
                    username, 
                    email, 
                    phone, 
                    password, 
                    role, 
                    gender, 
                    dob, 
                    account_status, 
                    created_at
                ) VALUES (
                    :full_name, 
                    :username, 
                    :email, 
                    :phone, 
                    :password, 
                    'patient', 
                    :gender, 
                    :dob, 
                    'active', 
                    NOW()
                )";

        $stmt = $pdo->prepare($sql);
        $result = $stmt->execute([
            ':full_name' => $full_name,
            ':username' => $username,
            ':email' => $email,
            ':phone' => $phone,
            ':password' => $hashed_password,
            ':gender' => $gender,
            ':dob' => $dob
        ]);

        if ($result) {
            // Get the new user ID
            $newUserId = $pdo->lastInsertId();

            // Commit transaction
            $pdo->commit();

            logMessage("User registered successfully: $username (ID: $newUserId)");

            echo json_encode([
                'status' => 'success',
                'message' => 'Registration successful! Please login.',
                'user_id' => $newUserId,
                'username' => $username,
                'redirect' => '../login.html'
            ]);
        } else {
            // Rollback transaction
            $pdo->rollBack();
            logMessage("Registration failed for: $username - Insert failed");
            echo json_encode(['status' => 'error', 'message' => 'Registration failed. Please try again.']);
        }
    } catch (PDOException $e) {
        // Rollback transaction on error
        $pdo->rollBack();
        throw $e;
    }
} catch (PDOException $e) {
    logMessage("Database Error: " . $e->getMessage());

    // Check for duplicate entry error
    if ($e->getCode() == 23000) {
        $errorMessage = 'Database constraint violation. ';
        if (strpos($e->getMessage(), 'username') !== false) {
            $errorMessage .= 'Username already taken.';
        } elseif (strpos($e->getMessage(), 'email') !== false) {
            $errorMessage .= 'Email already registered.';
        } else {
            $errorMessage .= 'Duplicate entry found.';
        }
        echo json_encode(['status' => 'error', 'message' => $errorMessage]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Database error occurred. Please try again.']);
    }
} catch (Exception $e) {
    logMessage("General Error: " . $e->getMessage());
    echo json_encode(['status' => 'error', 'message' => 'An error occurred. Please try again.']);
}
