<?php
// backend/session_debug.php
// Debug file to check session data

session_start();

echo "<h1>Session Debug Information</h1>";
echo "<hr>";

echo "<h2>Session Data:</h2>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";

echo "<hr>";

if (isset($_SESSION['user_id']) && $_SESSION['logged_in'] === true) {
    echo "<h2 style='color:green'>✅ User is LOGGED IN</h2>";
    echo "<p><strong>User ID:</strong> " . $_SESSION['user_id'] . "</p>";
    echo "<p><strong>Username:</strong> " . $_SESSION['username'] . "</p>";
    echo "<p><strong>Full Name:</strong> " . $_SESSION['full_name'] . "</p>";
    echo "<p><strong>Email:</strong> " . $_SESSION['email'] . "</p>";
    echo "<p><strong>Role:</strong> " . $_SESSION['role'] . "</p>";
    echo "<p><strong>Login Time:</strong> " . date('Y-m-d H:i:s', $_SESSION['login_time']) . "</p>";
} else {
    echo "<h2 style='color:red'>❌ User is NOT LOGGED IN</h2>";
}

echo "<hr>";
echo "<h2>Cookies:</h2>";
echo "<pre>";
print_r($_COOKIE);
echo "</pre>";

echo "<hr>";
echo "<h2>Session Configuration:</h2>";
echo "<pre>";
print_r(session_get_cookie_params());
echo "</pre>";
