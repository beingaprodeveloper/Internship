// frontend/assets/js/auth.js
function checkAuth(requiredRole) {
  fetch("../../backend/auth_check.php") // ← corrected from check_auth.php
    .then((response) => {
      if (response.status === 401) {
        throw new Error("Unauthorized");
      }
      return response.json();
    })
    .then((data) => {
      if (data.status !== "success") {
        window.location.href = "../login.html";
        return;
      }
      const userRole = data.user.role || "Patient";
      if (requiredRole && userRole !== requiredRole) {
        if (userRole === "Admin") {
          window.location.href = "../admin/dashboard.html";
        } else {
          window.location.href = "../patient/dashboard.html";
        }
        return;
      }
      const userNameElem = document.getElementById("user-name");
      if (userNameElem && data.user.name) {
        userNameElem.textContent = data.user.name.split(" ")[0];
      }
      const fullNameElem = document.getElementById("userName");
      if (fullNameElem && data.user.name) {
        fullNameElem.textContent = data.user.name;
      }
    })
    .catch((error) => {
      console.warn("Authentication failed, redirecting to login.", error);
      window.location.href = "../login.html";
    });
}
