// frontend/assets/dashboard.js
document.addEventListener("DOMContentLoaded", function () {
  "use strict";

  // ── AOS ──
  if (typeof AOS !== "undefined") {
    AOS.init({
      once: true,
      duration: 500,
      easing: "ease-out-cubic",
      offset: 20,
    });
  }

  // ── Sidebar toggle ──
  const sidebar = document.getElementById("sidebar");
  const hamburger = document.getElementById("hamburgerToggle");
  const mainContent = document.getElementById("mainContent");
  if (sidebar && hamburger) {
    hamburger.addEventListener("click", function () {
      sidebar.classList.toggle("minimised");
      if (window.innerWidth <= 768) {
        sidebar.classList.toggle("active");
      }
      const icon = this.querySelector("i");
      if (icon) {
        icon.className =
          sidebar.classList.contains("minimised") && window.innerWidth > 768
            ? "bi bi-list"
            : "bi bi-x-lg";
      }
    });
  }

  document.addEventListener("click", function (e) {
    if (window.innerWidth <= 768) {
      const isSidebar = sidebar.contains(e.target);
      const isHamburger = hamburger.contains(e.target);
      if (!isSidebar && !isHamburger && sidebar.classList.contains("active")) {
        sidebar.classList.remove("active");
      }
    }
  });

  // ── Set current date ──
  const topbarDate = document.getElementById("topbar-date");
  if (topbarDate) {
    const options = {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric",
    };
    topbarDate.textContent = new Date().toLocaleDateString("en-GB", options);
  }

  // ── Fetch dashboard data ──
  const apiUrl = "../../backend/admin_dashboard.php";

  fetch(apiUrl, { credentials: "same-origin" })
    .then((response) => {
      if (!response.ok)
        throw new Error(`HTTP error! status: ${response.status}`);
      return response.json();
    })
    .then((data) => {
      if (data.status !== "success")
        throw new Error(data.message || "Unknown error");
      renderDashboard(data);
      setupProfileModal(data.user);
    })
    .catch((error) => {
      console.error("Dashboard load error:", error);
      document.querySelectorAll(".text-muted").forEach((el) => {
        if (el.textContent.includes("Loading")) {
          el.textContent = "⚠️ Failed to load data. Please refresh.";
        }
      });
    });

  // ── Render function ──
  function renderDashboard(data) {
    const { user, stats, appointments, notifications, audit_logs, chart } =
      data;

    // 1. User info
    const userName = user.full_name || "Admin";
    const userInitials = user.initials || "AD";
    document.getElementById("sidebar-user-name").textContent = userName;
    document.getElementById("sidebar-user-avatar").textContent = userInitials;
    document.getElementById("topbar-avatar").textContent = userInitials;

    // 2. Notification badge
    document.getElementById("notif-badge").textContent =
      stats.unread_notifications || 0;
    document.getElementById("notif-badge-count").textContent =
      `${stats.unread_notifications || 0} unread`;

    // 3. Stats – define ONLY the statistics we want
    const allStatItems = [
      {
        label: "Total Users",
        value: stats.total_users,
        icon: "bi-people",
        gradient: "gradient-wine",
      },
      {
        label: "Doctors",
        value: stats.total_doctors,
        icon: "bi-person-badge",
        gradient: "gradient-emerald",
      },
      {
        label: "Patients",
        value: stats.total_patients,
        icon: "bi-person",
        gradient: "gradient-gold",
      },
      {
        label: "Admins",
        value: stats.total_admins,
        icon: "bi-shield",
        gradient: "gradient-teal",
      },
      {
        label: "Active Users",
        value: stats.active_users,
        icon: "bi-check-circle",
        gradient: "gradient-emerald",
      },
      {
        label: "Inactive",
        value: stats.inactive_users,
        icon: "bi-pause-circle",
        gradient: "gradient-sky",
      },
      {
        label: "Suspended",
        value: stats.suspended_users,
        icon: "bi-exclamation-triangle",
        gradient: "gradient-coral",
      },
      {
        label: "Specializations",
        value: stats.total_specializations,
        icon: "bi-tags",
        gradient: "gradient-purple",
      },
      {
        label: "Treatments",
        value: stats.total_treatments,
        icon: "bi-capsule",
        gradient: "gradient-rose",
      },
      {
        label: "Appointments",
        value: stats.total_appointments,
        icon: "bi-calendar3",
        gradient: "gradient-wine",
      },
      {
        label: "Today",
        value: stats.today_appointments,
        icon: "bi-calendar-day",
        gradient: "gradient-gold",
      },
      {
        label: "Upcoming",
        value: stats.upcoming_appointments,
        icon: "bi-clock",
        gradient: "gradient-emerald",
      },
      {
        label: "Completed",
        value: stats.completed_appointments,
        icon: "bi-check2-all",
        gradient: "gradient-emerald",
      },
      {
        label: "Cancelled",
        value: stats.cancelled_appointments,
        icon: "bi-x-circle",
        gradient: "gradient-coral",
      },
      {
        label: "No Show",
        value: stats.no_show_appointments,
        icon: "bi-eye-slash",
        gradient: "gradient-sky",
      },
      {
        label: "Premium Bookings",
        value: stats.total_premium_bookings,
        icon: "bi-gem",
        gradient: "gradient-gold",
      },
      {
        label: "Pending Premium",
        value: stats.pending_premium,
        icon: "bi-hourglass-split",
        gradient: "gradient-rose",
      },
      {
        label: "Confirmed Premium",
        value: stats.confirmed_premium,
        icon: "bi-check-circle",
        gradient: "gradient-emerald",
      },
      {
        label: "Completed Premium",
        value: stats.completed_premium,
        icon: "bi-check2-all",
        gradient: "gradient-emerald",
      },
      {
        label: "Cancelled Premium",
        value: stats.cancelled_premium,
        icon: "bi-x-circle",
        gradient: "gradient-coral",
      },
      {
        label: "Available Doctors",
        value: stats.available_doctors,
        icon: "bi-check-circle",
        gradient: "gradient-emerald",
      },
      {
        label: "Unavailable Doctors",
        value: stats.unavailable_doctors,
        icon: "bi-clock",
        gradient: "gradient-sky",
      },
      {
        label: "Notifications",
        value: stats.total_notifications,
        icon: "bi-bell",
        gradient: "gradient-gold",
      },
      {
        label: "Audit Logs",
        value: stats.total_audit_logs,
        icon: "bi-shield-check",
        gradient: "gradient-wine",
      },
    ];

    // Top 8 (most important)
    const top8 = allStatItems.slice(0, 8);
    const rest = allStatItems.slice(8);

    function renderStatCards(containerId, items, delayOffset = 0) {
      const container = document.getElementById(containerId);
      if (!container) return;
      container.innerHTML = "";
      items.forEach((item, index) => {
        const div = document.createElement("div");
        div.className = `stat-card ${item.gradient}`;
        div.setAttribute("data-aos", "fade-up");
        div.setAttribute(
          "data-aos-delay",
          (50 + index * 20 + delayOffset).toString(),
        );
        div.innerHTML = `
                    <div class="stat-card-top">
                        <div class="stat-label">${item.label}</div>
                        <div class="stat-icon"><i class="bi ${item.icon}"></i></div>
                    </div>
                    <div class="stat-value">${item.value}</div>
                    <div class="stat-sub">${item.label}</div>
                `;
        container.appendChild(div);
      });
    }

    renderStatCards("stats-grid-top", top8, 0);
    renderStatCards("stats-grid-more", rest, 200);

    // ── View More toggle ──
    const moreContainer = document.getElementById("stats-grid-more");
    const toggleBtn = document.getElementById("viewMoreStatsBtn");
    const toggleIcon = document.getElementById("viewMoreIcon");
    let isOpen = false;

    toggleBtn.addEventListener("click", function () {
      isOpen = !isOpen;
      if (isOpen) {
        moreContainer.classList.add("open");
        toggleBtn.querySelector("span").textContent = "View Less Stats";
        toggleIcon.classList.add("rotated");
      } else {
        moreContainer.classList.remove("open");
        toggleBtn.querySelector("span").textContent = "View More Stats";
        toggleIcon.classList.remove("rotated");
      }
    });

    // 4. Recent appointments (table rows)
    const tbody = document.getElementById("appointment-list");
    if (appointments && appointments.length > 0) {
      tbody.innerHTML = appointments
        .map((appt) => {
          const status = appt.status || "scheduled";
          const patient = appt.patient_name || "Unknown";
          const doctor = appt.doctor_name || "—";
          const date = appt.appointment_date
            ? new Date(appt.appointment_date).toLocaleDateString()
            : "—";
          const time = appt.start_time
            ? new Date("1970-01-01T" + appt.start_time).toLocaleTimeString([], {
                hour: "2-digit",
                minute: "2-digit",
              })
            : "--:--";
          return `<tr>
                    <td>${patient}</td>
                    <td>${doctor}</td>
                    <td>${date}</td>
                    <td>${time}</td>
                    <td><span class="status-badge ${status}">${status}</span></td>
                </tr>`;
        })
        .join("");
    } else {
      tbody.innerHTML = `<tr><td colspan="5" class="text-center text-muted">No appointments found</td></tr>`;
    }

    // 5. Notifications
    const notifList = document.getElementById("notification-list");
    if (notifications && notifications.length > 0) {
      notifList.innerHTML = notifications
        .map((notif) => {
          const message = notif.message || "";
          const time = notif.created_at
            ? new Date(notif.created_at).toLocaleTimeString([], {
                hour: "2-digit",
                minute: "2-digit",
              })
            : "";
          const isRead = notif.is_read ? "read" : "unread";
          return `<div class="list-item notification-item ${isRead}">
                    <div class="left">
                        <div class="title">${message}</div>
                        <div class="sub">${time}</div>
                    </div>
                    <div class="right">${!notif.is_read ? '<span class="badge">New</span>' : ""}</div>
                </div>`;
        })
        .join("");
    } else {
      notifList.innerHTML = `<div class="text-center text-muted">No recent notifications</div>`;
    }

    // 6. Audit logs
    const auditList = document.getElementById("audit-list");
    if (audit_logs && audit_logs.length > 0) {
      auditList.innerHTML = audit_logs
        .map((log) => {
          const action = log.action || "";
          const user_id = log.user_id || "";
          const time = log.timestamp
            ? new Date(log.timestamp).toLocaleTimeString([], {
                hour: "2-digit",
                minute: "2-digit",
              })
            : "";
          return `<div class="list-item">
                    <div class="left">
                        <div class="title">${action}</div>
                        <div class="sub">User #${user_id}</div>
                    </div>
                    <div class="right">${time}</div>
                </div>`;
        })
        .join("");
    } else {
      auditList.innerHTML = `<div class="text-center text-muted">No recent logs</div>`;
    }
    document.getElementById("total-audit-logs").textContent =
      stats.total_audit_logs || 0;

    // 7. Charts (unchanged)
    if (typeof Chart !== "undefined" && chart) {
      const ctx1 = document
        .getElementById("appointmentChart")
        ?.getContext("2d");
      if (ctx1) {
        new Chart(ctx1, {
          type: "line",
          data: {
            labels: chart.labels,
            datasets: [
              {
                label: "Appointments",
                data: chart.values,
                borderColor: "#722F37",
                backgroundColor: "rgba(114,47,55,0.08)",
                tension: 0.3,
                fill: true,
                pointBackgroundColor: "#C9A86C",
                pointRadius: 3,
              },
            ],
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
              y: { beginAtZero: true, grid: { color: "rgba(0,0,0,0.04)" } },
              x: { grid: { display: false } },
            },
          },
        });
      }

      const ctx2 = document.getElementById("statusChart")?.getContext("2d");
      if (ctx2) {
        new Chart(ctx2, {
          type: "doughnut",
          data: {
            labels: chart.status_labels || [
              "Scheduled",
              "Completed",
              "Cancelled",
              "No Show",
            ],
            datasets: [
              {
                data: chart.status_values || [0, 0, 0, 0],
                backgroundColor: ["#C9A86C", "#1B5E20", "#722F37", "#9E9E9E"],
                borderWidth: 0,
              },
            ],
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                position: "bottom",
                labels: { boxWidth: 10, padding: 10, color: "#2D2A24" },
              },
            },
            cutout: "70%",
          },
        });
      }
    }
  }

  // ── Setup Profile Modal (unchanged) ──
  function setupProfileModal(user) {
    const modal = document.getElementById("profileModal");
    const closeBtn = document.getElementById("profileModalClose");
    const avatarEl = document.getElementById("modalAvatar");
    const titleEl = document.getElementById("modalTitle");
    const infoGrid = document.getElementById("modalInfoGrid");

    const fullName = user.full_name || "Administrator";
    const initials = user.initials || "AD";
    const username = user.username || "admin";
    const email = user.email || "admin@example.com";
    const phone = user.phone || "—";
    const gender = user.gender || "—";
    const dob = user.dob || "—";
    const address = user.address || "—";
    const status = user.status || "active";
    const role = user.role || "admin";
    const createdAt = user.created_at
      ? new Date(user.created_at).toLocaleString()
      : "—";
    const updatedAt = user.updated_at
      ? new Date(user.updated_at).toLocaleString()
      : "—";

    if (user.profile_image) {
      avatarEl.innerHTML = `<img src="${user.profile_image}" alt="Profile">`;
    } else {
      avatarEl.textContent = initials;
    }

    titleEl.innerHTML = `${fullName} <small>@${username} · ${role}</small>`;

    infoGrid.innerHTML = `
            <div class="info-item"><span class="label">Full Name</span><span class="value">${fullName}</span></div>
            <div class="info-item"><span class="label">Username</span><span class="value">${username}</span></div>
            <div class="info-item"><span class="label">Email</span><span class="value">${email}</span></div>
            <div class="info-item"><span class="label">Phone</span><span class="value">${phone}</span></div>
            <div class="info-item"><span class="label">Gender</span><span class="value">${gender}</span></div>
            <div class="info-item"><span class="label">Date of Birth</span><span class="value">${dob}</span></div>
            <div class="info-item"><span class="label">Address</span><span class="value">${address}</span></div>
            <div class="info-item"><span class="label">Status</span><span class="value"><span class="status-badge ${status}">${status}</span></span></div>
            <div class="info-item"><span class="label">Account Created</span><span class="value">${createdAt}</span></div>
            <div class="info-item"><span class="label">Last Updated</span><span class="value">${updatedAt}</span></div>
        `;

    const triggers = [
      document.getElementById("sidebar-user-avatar"),
      document.getElementById("sidebar-user-name"),
      document.getElementById("topbar-avatar"),
    ];
    triggers.forEach((el) => {
      if (el) {
        el.style.cursor = "pointer";
        el.addEventListener("click", () => modal.classList.add("active"));
      }
    });

    closeBtn.addEventListener("click", () => modal.classList.remove("active"));
    modal.addEventListener("click", (e) => {
      if (e.target === modal) modal.classList.remove("active");
    });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") modal.classList.remove("active");
    });
  }
});
