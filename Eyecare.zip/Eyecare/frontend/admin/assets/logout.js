// frontend/assets/js/logout.js
document.addEventListener("DOMContentLoaded", () => {
  const logoutBtn = document.getElementById("logoutBtn");
  if (logoutBtn) {
    logoutBtn.addEventListener("click", (e) => {
      e.preventDefault();

      const originalText = logoutBtn.innerHTML;
      logoutBtn.disabled = true;
      logoutBtn.textContent = "Logging out...";
      fetch("../../backend/logout.php", {
        headers: {
          Accept: "application/json",
        },
      })
        .then((response) => {
          if (!response.ok) {
            throw new Error("Logout request failed");
          }
          return response.json();
        })
        .then((data) => {
          if (data.status === "success") {
            window.location.href = "../login.html";
          } else {
            alert("Logout failed: " + (data.message || "Unknown error"));
            logoutBtn.disabled = false;
            logoutBtn.innerHTML = originalText;
          }
        })
        .catch((error) => {
          console.warn(
            "Logout fetch failed, executing fallback redirect: ",
            error,
          );
          // Direct navigation fallback
          window.location.href = "../../backend/logout.php";
        });
    });
  }
});
