function checkAuth(requiredRole) {
  fetch("../../backend/auth.php")
    .then((response) => response.json())

    .then((data) => {
      if (data.status !== "success") {
        window.location.href = "../index.html";
        return;
      }

      let userRole = data.user.role;

      if (userRole !== requiredRole) {
        window.location.href = "../index.html";

        return;
      }

      let userName = document.getElementById("userName");

      if (userName) {
        userName.innerHTML = data.user.name;
      }
    })

    .catch(() => {
      window.location.href = "../index.html";
    });
}
