document
  .getElementById("forgotPasswordForm")
  .addEventListener("submit", async function (e) {
    e.preventDefault();

    const formData = new FormData(this);

    try {
      const response = await fetch("../../backend/forgot_password.php", {
        method: "POST",

        body: formData,
      });

      const data = await response.json();

      document.getElementById("message").innerText = data.message;
    } catch (error) {
      document.getElementById("message").innerText =
        "Unable to connect to the server.";
    }
  });
