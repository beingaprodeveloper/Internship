/**
 * Authentication - Registration Module
 * EyeCare Appointment System
 *
 * All data is sent securely to the backend for processing
 * No data is stored or processed on the client side
 */

document.addEventListener("DOMContentLoaded", function () {
  // Get the registration form
  const form = document.getElementById("registerForm");

  if (!form) {
    console.error("Registration form not found.");
    return;
  }

  // Get message display element
  const messageDiv =
    document.getElementById("message") || createMessageElement(form);

  // Create message element if it doesn't exist
  function createMessageElement(parentForm) {
    const div = document.createElement("div");
    div.id = "message";
    div.className = "message-box";
    div.style.display = "none";
    parentForm.appendChild(div);
    return div;
  }

  // Password toggle function
  window.togglePassword = function (inputId, button) {
    const input = document.getElementById(inputId);
    if (!input) return;

    const icon = button.querySelector("i");
    if (input.type === "password") {
      input.type = "text";
      if (icon) {
        icon.classList.remove("bi-eye");
        icon.classList.add("bi-eye-slash");
      }
    } else {
      input.type = "password";
      if (icon) {
        icon.classList.remove("bi-eye-slash");
        icon.classList.add("bi-eye");
      }
    }
  };

  // Show message function
  function showMessage(message, type) {
    if (!messageDiv) return;

    messageDiv.style.display = "block";
    messageDiv.className = "message-box";
    messageDiv.textContent = message;

    if (type === "success") {
      messageDiv.classList.add("success");
    } else if (type === "error") {
      messageDiv.classList.add("error");
    }
  }

  // Clear message function
  function clearMessage() {
    if (!messageDiv) return;
    messageDiv.style.display = "none";
    messageDiv.className = "message-box";
    messageDiv.textContent = "";
  }

  // Form submission handler
  form.addEventListener("submit", async function (e) {
    e.preventDefault();

    // Clear previous messages
    clearMessage();

    // Get submit button
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;

    // Get form data - SENT DIRECTLY TO BACKEND
    const formData = new FormData(form);

    // Disable button and show loading state
    submitBtn.disabled = true;
    submitBtn.innerHTML =
      '<span>Creating Account...</span> <i class="bi bi-hourglass-split spinning"></i>';

    try {
      // Send data to backend for processing
      const response = await fetch("../../backend/register.php", {
        method: "POST",
        body: formData,
      });

      // Check if response is OK
      if (!response.ok) {
        const errorText = await response.text();
        console.error("Server error:", errorText);
        throw new Error(`Server error: ${response.status}`);
      }

      // Parse JSON response
      let result;
      try {
        result = await response.json();
      } catch (jsonError) {
        console.error("JSON parse error:", jsonError);
        throw new Error("Invalid server response");
      }

      // Handle the response from backend
      if (result.status === "success") {
        // Show success message
        showMessage(result.message || "Registration successful!", "success");

        // Reset form
        form.reset();

        // Re-enable button
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;

        // Redirect after delay
        const redirectUrl = result.redirect || "../login.html";
        setTimeout(() => {
          window.location.href = redirectUrl;
        }, 2000);
      } else {
        // Show error message from backend
        showMessage(result.message || "Registration failed.", "error");

        // Re-enable button
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;
      }
    } catch (error) {
      console.error("Registration Error:", error);

      // Show user-friendly error message
      showMessage(
        "Unable to connect to server. Please check your connection and try again.",
        "error",
      );

      // Re-enable button
      submitBtn.disabled = false;
      submitBtn.innerHTML = originalText;
    }
  });

  // ========== UI ENHANCEMENTS (Client-side only - no data processing) ==========

  // Password strength indicator (visual only)
  const passwordInput = document.getElementById("password");
  if (passwordInput) {
    passwordInput.addEventListener("input", function () {
      const password = this.value;
      const strengthDiv =
        document.getElementById("password-strength") ||
        createStrengthIndicator(this);

      if (password.length === 0) {
        strengthDiv.textContent = "";
        strengthDiv.className = "password-strength";
        return;
      }

      // Visual feedback only - actual validation done on backend
      const strength = getPasswordStrength(password);
      if (strength === "strong") {
        strengthDiv.textContent = "✓ Strong password";
        strengthDiv.className = "password-strength strong";
        strengthDiv.style.color = "#28a745";
      } else if (strength === "medium") {
        strengthDiv.textContent = "⚠️ Medium strength";
        strengthDiv.className = "password-strength medium";
        strengthDiv.style.color = "#ffc107";
      } else {
        strengthDiv.textContent = "❌ Weak password";
        strengthDiv.className = "password-strength weak";
        strengthDiv.style.color = "#dc3545";
      }
    });
  }

  function getPasswordStrength(password) {
    let score = 0;
    if (password.length >= 8) score++;
    if (password.length >= 12) score++;
    if (/[A-Z]/.test(password)) score++;
    if (/[a-z]/.test(password)) score++;
    if (/[0-9]/.test(password)) score++;
    if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) score++;

    if (score >= 5) return "strong";
    if (score >= 3) return "medium";
    return "weak";
  }

  function createStrengthIndicator(input) {
    const div = document.createElement("div");
    div.id = "password-strength";
    div.className = "password-strength";
    div.style.fontSize = "12px";
    div.style.marginTop = "4px";
    input.parentNode.appendChild(div);
    return div;
  }

  // Password match indicator (visual only)
  const confirmPasswordInput = document.getElementById("confirm_password");
  if (confirmPasswordInput && passwordInput) {
    confirmPasswordInput.addEventListener("input", function () {
      const matchDiv =
        document.getElementById("password-match") || createMatchIndicator(this);

      if (this.value.length === 0) {
        matchDiv.textContent = "";
        matchDiv.className = "password-match";
        return;
      }

      if (this.value === passwordInput.value) {
        matchDiv.textContent = "✓ Passwords match";
        matchDiv.className = "password-match match";
        matchDiv.style.color = "#28a745";
      } else {
        matchDiv.textContent = "✗ Passwords do not match";
        matchDiv.className = "password-match no-match";
        matchDiv.style.color = "#dc3545";
      }
    });
  }

  function createMatchIndicator(input) {
    const div = document.createElement("div");
    div.id = "password-match";
    div.className = "password-match";
    div.style.fontSize = "12px";
    div.style.marginTop = "4px";
    input.parentNode.appendChild(div);
    return div;
  }

  console.log("Registration module loaded successfully");
});
