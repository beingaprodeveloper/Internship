const params = new URLSearchParams(window.location.search);

const token = params.get("token");

if (!token) {
  document.getElementById("message").innerText = "Invalid password reset link.";
  throw new Error("Missing token");
}

// Verify token immediately
fetch("../../backend/verify_reset_token.php", {
  method: "POST",
  headers: {
    "Content-Type": "application/x-www-form-urlencoded",
  },
  body: "token=" + encodeURIComponent(token),
})
  .then((response) => response.json())
  .then((data) => {
    if (data.status !== "success") {
      document.getElementById("message").innerText = data.message;

      document.getElementById("resetPasswordForm").style.display = "none";
    }
  });

document
  .getElementById("resetPasswordForm")
  .addEventListener("submit", function (e) {
    e.preventDefault();

    const password = document.getElementById("newPassword").value;

    const confirm = document.getElementById("confirmPassword").value;

    const formData = new FormData();

    formData.append("token", token);
    formData.append("password", password);
    formData.append("confirm_password", confirm);

    fetch("../../backend/update_password.php", {
      method: "POST",

      body: formData,
    })
      .then((response) => response.json())

      .then((data) => {
        document.getElementById("message").innerText = data.message;

        if (data.status === "success") {
          setTimeout(() => {
            window.location.href = "../index.html";
          }, 2000);
        }
      });
  });
