(function () {
  "use strict";

  // ── API Endpoint ──────────────────────────
  const API = "../../backend/api/booking-api.php";

  // ── STATE ─────────────────────────────
  let state = {
    specializations: [],
    treatments: [],
    doctors: [],
    selectedSpecId: null,
    selectedTreatment: null,
    selectedDoctorId: null,
    selectedDate: null,
    selectedTime: null,
    calendarDate: new Date(),
    popupDoctorId: null,
  };

  // ── HELPERS ──────────────────────────
  function formatCurrency(amount) {
    return "₹" + Number(amount).toLocaleString("en-IN");
  }

  function formatDate(d) {
    if (!d) return "—";
    const dt = new Date(d);
    return `${dt.getDate()} ${["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"][dt.getMonth()]} ${dt.getFullYear()}`;
  }

  function formatTime(t) {
    if (!t) return "—";
    const [h, m] = t.split(":").map(Number);
    const ampm = h >= 12 ? "PM" : "AM";
    const h12 = h % 12 || 12;
    return `${h12}:${String(m).padStart(2, "0")} ${ampm}`;
  }

  function getDateKey(d) {
    const dt = new Date(d);
    return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, "0")}-${String(dt.getDate()).padStart(2, "0")}`;
  }

  function isSameDay(d1, d2) {
    return (
      d1.getFullYear() === d2.getFullYear() &&
      d1.getMonth() === d2.getMonth() &&
      d1.getDate() === d2.getDate()
    );
  }

  function isToday(d) {
    return isSameDay(d, new Date());
  }

  function getSpecName(id) {
    const s = state.specializations.find((s) => s.id === id);
    return s ? s.name : "—";
  }

  function getSpecIcon(id) {
    const s = state.specializations.find((s) => s.id === id);
    return s ? s.icon : "👁️";
  }

  function getDoctor(id) {
    return state.doctors.find((d) => d.id === id);
  }

  function getDoctorsByTreatment(treatmentId) {
    return state.doctors.filter(
      (d) => d.treatment_ids && d.treatment_ids.includes(treatmentId),
    );
  }

  // ── API CALLS ──────────────────────────
  async function apiFetch(action, method = "GET", body = null, params = {}) {
    let url = API + "?action=" + encodeURIComponent(action);
    for (const [key, value] of Object.entries(params)) {
      url += "&" + encodeURIComponent(key) + "=" + encodeURIComponent(value);
    }
    const options = {
      method: method,
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
    };
    if (body) options.body = JSON.stringify(body);
    try {
      const resp = await fetch(url, options);
      const data = await resp.json();
      if (!resp.ok) throw new Error(data.error || "Server error");
      return data;
    } catch (err) {
      showToast("❌ " + err.message, true);
      throw err;
    }
  }

  // ── LOAD DATA ─────────────────────────
  async function loadAllData() {
    try {
      const [specs, doctors] = await Promise.all([
        apiFetch("get_specializations"),
        apiFetch("get_doctors"),
      ]);
      state.specializations = specs || [];
      state.doctors = doctors || [];
      renderSpecs();
    } catch (err) {
      console.error("Load error:", err);
    }
  }

  // ── LOAD TREATMENTS ──────────────────
  async function loadTreatments(specId) {
    console.log("loadTreatments called with specId:", specId);
    try {
      const treatments = await apiFetch("get_treatments", "GET", null, {
        spec_id: specId,
      });
      console.log("Treatments received:", treatments);
      state.treatments = treatments || [];
      renderTreatments();
    } catch (err) {
      console.error("loadTreatments error:", err);
      state.treatments = [];
      renderTreatments();
    }
  }

  // ── RENDER: Specializations ──────────
  function renderSpecs() {
    const grid = document.getElementById("specGrid");
    if (!state.specializations.length) {
      grid.innerHTML =
        '<div style="grid-column:1/-1;padding:30px;text-align:center;color:var(--text-muted);">Loading specializations...</div>';
      return;
    }
    grid.innerHTML = state.specializations
      .map(
        (spec) => `
            <button class="option-card ${state.selectedSpecId === spec.id ? "selected" : ""}"
                    role="radio"
                    aria-checked="${state.selectedSpecId === spec.id}"
                    data-spec-id="${spec.id}">
                <span class="card-icon">${spec.icon || "👁️"}</span> ${spec.name}
            </button>
          `,
      )
      .join("");

    grid.querySelectorAll(".option-card").forEach((btn) => {
      btn.addEventListener("click", () => {
        const specId = parseInt(btn.dataset.specId);
        state.selectedSpecId = specId;
        state.selectedTreatment = null;
        state.selectedDoctorId = null;
        state.selectedDate = null;
        state.selectedTime = null;
        renderSpecs();
        updateStatus("status1", "Done ✓", true);
        markCompleted("container1");
        loadTreatments(specId);
        revealContainer("container2");
        hideContainersAfter(2);
      });
    });
  }

  // ── RENDER: Treatments ────────────────
  function renderTreatments() {
    const grid = document.getElementById("treatmentGrid");
    const subtitle = document.getElementById("c2Subtitle");
    if (!state.selectedSpecId) {
      grid.innerHTML = "";
      subtitle.textContent = "Please select a specialization first.";
      return;
    }
    const specName = getSpecName(state.selectedSpecId);
    subtitle.textContent = `Choose a treatment for ${specName}`;

    if (state.treatments.length === 0) {
      grid.innerHTML =
        '<div style="grid-column:1/-1;padding:20px;text-align:center;color:var(--text-muted);">No treatments available for this specialization.</div>';
      return;
    }

    grid.innerHTML = state.treatments
      .map((t) => {
        const selected =
          state.selectedTreatment && state.selectedTreatment.id === t.id;
        const feeDisplay = t.surgery_fee
          ? `<span><i class="fas fa-syringe"></i> Surgery: ${formatCurrency(t.surgery_fee)}</span>`
          : "";
        const includes = t.package_includes
          ? t.package_includes
              .split(",")
              .map(
                (i) => `<span><i class="fas fa-check"></i> ${i.trim()}</span>`,
              )
              .join("")
          : "";
        return `
            <div class="treatment-card ${selected ? "selected" : ""}" data-treatment-id="${t.id}">
              <div class="t-name">${t.name}</div>
              <div class="t-desc">${t.description || ""}</div>
              <div class="t-meta">
                <span><i class="far fa-clock"></i> ${t.duration || "—"}</span>
                <span><i class="fas fa-rupee-sign"></i> Consult: ${formatCurrency(t.consult_fee)}</span>
                ${feeDisplay}
                ${t.recovery ? `<span><i class="fas fa-heartbeat"></i> Recovery: ${t.recovery}</span>` : ""}
              </div>
              ${
                t.package_name
                  ? `
                <div class="t-package">
                  <div class="p-name">📦 ${t.package_name}</div>
                  <div class="p-price">${formatCurrency(t.package_price || t.consult_fee)}</div>
                  ${includes ? `<div class="p-includes">${includes}</div>` : ""}
                </div>
              `
                  : ""
              }
              <button class="btn-select-package" data-treatment-id="${t.id}">
                <i class="fas fa-hand-pointer"></i> Select Package
              </button>
            </div>
          `;
      })
      .join("");

    grid.querySelectorAll(".btn-select-package").forEach((btn) => {
      btn.addEventListener("click", function (e) {
        e.stopPropagation();
        const id = parseInt(this.dataset.treatmentId);
        const treatment = state.treatments.find((t) => t.id === id);
        if (treatment) {
          console.log("Treatment selected:", treatment);
          state.selectedTreatment = treatment;
          state.selectedDoctorId = null;
          state.selectedDate = null;
          state.selectedTime = null;
          renderTreatments();
          updateStatus("status2", "Done ✓", true);
          markCompleted("container2");
          renderDoctors();
          revealContainer("container3");
          hideContainersAfter(3);
        }
      });
    });
  }

  // ── RENDER: Doctors ────────────────── (FIXED)
  function renderDoctors() {
    const grid = document.getElementById("doctorGrid");
    const subtitle = document.getElementById("c3Subtitle");
    if (!state.selectedTreatment) {
      grid.innerHTML = "";
      subtitle.textContent = "Please select a treatment first.";
      return;
    }

    subtitle.textContent = `Available specialists for ${state.selectedTreatment.name}`;
    const treatmentId = state.selectedTreatment.id;
    const available = getDoctorsByTreatment(treatmentId);

    // 🟢 Log after variables are defined
    console.log("Treatment ID:", treatmentId);
    console.log("All doctors:", state.doctors);
    console.log("Filtered doctors:", available);

    if (available.length === 0) {
      grid.innerHTML =
        '<div style="grid-column:1/-1;padding:20px;text-align:center;color:var(--text-muted);">No doctors available for this treatment.</div>';
      return;
    }
    grid.innerHTML = available
      .map((doc) => {
        const selected = state.selectedDoctorId === doc.id;
        const todayBadge = doc.available_today
          ? '<span class="badge-today"><i class="fas fa-circle-check"></i> Available Today</span>'
          : "";
        return `
            <div class="doctor-card ${selected ? "selected" : ""}" data-doctor-id="${doc.id}">
              <div class="avatar">${doc.photo || "👨"}</div>
              <div class="info">
                <div class="name">${doc.name} ${todayBadge}</div>
                <div class="spec">${getSpecName(doc.specialization_id)}</div>
                <div class="rating">⭐ ${doc.rating || 0} <span>(${doc.patients_treated || 0} patients)</span></div>
                <div style="font-size:0.75rem;color:var(--text-muted);">💰 ${formatCurrency(doc.fee)} · ${doc.experience || "—"}</div>
              </div>
              <button class="btn-view-profile" data-doctor-id="${doc.id}">View Profile</button>
            </div>
          `;
      })
      .join("");

    grid.querySelectorAll(".doctor-card").forEach((card) => {
      card.addEventListener("click", () => {
        const docId = parseInt(card.dataset.doctorId);
        state.selectedDoctorId = docId;
        state.selectedDate = null;
        state.selectedTime = null;
        renderDoctors();
        updateStatus("status3", "Done ✓", true);
        markCompleted("container3");
        renderCalendar();
        renderSlots();
        revealContainer("container4");
        hideContainersAfter(4);
      });
    });

    grid.querySelectorAll(".btn-view-profile").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        const docId = parseInt(btn.dataset.doctorId);
        openDoctorPopup(docId);
      });
    });
  }

  async function fetchPatients() {
    try {
      const url = API + "?action=get_all_patients";
      console.log("Fetching:", url);
      const resp = await fetch(url, { credentials: "include" });
      const text = await resp.text();
      console.log("Raw response:", text);
      let data;
      try {
        data = JSON.parse(text);
      } catch (e) {
        console.error("JSON parse error:", e);
        showToast("Server error: " + text.substring(0, 100), true);
        return [];
      }
      if (!resp.ok) throw new Error(data.error || "Failed to load patients");
      console.log("Patients data:", data);
      return data;
    } catch (err) {
      showToast("❌ " + err.message, true);
      return [];
    }
  }

  // ── DOCTOR POPUP ─────────────────────
  async function openDoctorPopup(docId) {
    try {
      const doc = await apiFetch("get_doctor", "GET", null, {
        id: docId,
      });
      state.popupDoctorId = docId;
      const overlay = document.getElementById("doctorPopup");
      const content = document.getElementById("popupContent");
      const reviewsHtml =
        (doc.reviews ? JSON.parse(doc.reviews) : [])
          .map(
            (r) =>
              `<div style="background:#f8fafc;padding:10px 14px;border-radius:8px;border-left:3px solid var(--primary-light);margin-bottom:6px;"><strong>${r.name}</strong> ⭐${r.rating}<br><span style="color:var(--text-muted);font-size:0.8rem;">${r.text}</span></div>`,
          )
          .join("") || "No reviews.";

      const tags = (doc.certifications ? doc.certifications.split(",") : [])
        .map((c) => `<span class="tag">${c.trim()}</span>`)
        .join("");

      content.innerHTML = `
          <div class="popup-doctor-header">
            <div class="photo">${doc.photo || "👨"}</div>
            <div class="info">
              <div class="name">${doc.name}</div>
              <div class="qual">${doc.qualification || "—"}</div>
              <div style="font-size:0.85rem;color:var(--text-muted);">${doc.experience || "—"} · ⭐ ${doc.rating || 0} · ${doc.patients_treated || 0} patients</div>
              <div style="font-size:0.85rem;color:var(--text-muted);">🗣 ${doc.languages || "—"}</div>
              <div style="font-weight:700;color:var(--primary-dark);margin-top:4px;">💰 ${formatCurrency(doc.fee)} consultation fee</div>
            </div>
          </div>
          <div class="popup-body-section">
            <div class="s-title">Biography</div><div class="s-text">${doc.biography || "—"}</div>
          </div>
          ${tags ? `<div class="popup-body-section"><div class="s-title">Certifications</div><div class="popup-tags">${tags}</div></div>` : ""}
          <div class="popup-body-section"><div class="s-title">Hospital</div><div class="s-text">${doc.hospital_branch || "—"}</div></div>
          <div class="popup-body-section"><div class="s-title">Working Days</div><div class="s-text">${
            doc.working_days
              ? doc.working_days
                  .split(",")
                  .map(
                    (d) =>
                      ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][
                        parseInt(d)
                      ],
                  )
                  .join(", ")
              : "—"
          } · ${doc.working_hours_start || "—"} – ${doc.working_hours_end || "—"}</div></div>
          <div class="popup-body-section"><div class="s-title">Reviews</div>${reviewsHtml}</div>
          <div class="popup-actions">
            <button class="btn-select" id="popupSelectDoctor"><i class="fas fa-user-check"></i> Select Doctor</button>
            <button class="btn-close-popup" id="popupCloseBtn">Close</button>
          </div>
        `;
      overlay.classList.add("open");

      document
        .getElementById("popupSelectDoctor")
        .addEventListener("click", () => {
          state.selectedDoctorId = docId;
          overlay.classList.remove("open");
          renderDoctors();
          updateStatus("status3", "Done ✓", true);
          markCompleted("container3");
          renderCalendar();
          renderSlots();
          revealContainer("container4");
          hideContainersAfter(4);
        });
      document
        .getElementById("popupCloseBtn")
        .addEventListener("click", () => overlay.classList.remove("open"));
      document
        .getElementById("popupClose")
        .addEventListener("click", () => overlay.classList.remove("open"));
      overlay.addEventListener("click", (e) => {
        if (e.target === overlay) overlay.classList.remove("open");
      });
    } catch (err) {
      showToast("Failed to load doctor details", true);
    }
  }

  // ── CALENDAR & SLOTS ─────────────────
  function renderCalendar() {
    const container = document.getElementById("calendarContainer");
    const date = state.calendarDate;
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const today = new Date();
    const todayKey = getDateKey(today);
    const doc = getDoctor(state.selectedDoctorId);
    const workingDays = doc
      ? doc.working_days
        ? doc.working_days.split(",").map(Number)
        : []
      : [];

    let html = `<div class="calendar-header"><button data-cal-nav="prev"><i class="fas fa-chevron-left"></i></button><span class="month">${["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"][month]} ${year}</span><button data-cal-nav="next"><i class="fas fa-chevron-right"></i></button></div><div class="calendar-grid">${["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => `<div class="day-name">${d}</div>`).join("")}`;
    for (let i = 0; i < firstDay; i++) html += `<div class="day empty"></div>`;
    for (let d = 1; d <= daysInMonth; d++) {
      const dt = new Date(year, month, d);
      const key = getDateKey(dt);
      const dow = dt.getDay();
      const isDisabled = !doc || !workingDays.includes(dow) || key < todayKey;
      const isSelected = state.selectedDate === key;
      const isTodayFlag = isToday(dt);
      let cls = "day";
      if (isDisabled) cls += " disabled";
      if (isSelected) cls += " selected";
      if (isTodayFlag) cls += " today";
      html += `<button class="${cls}" data-date="${key}" ${isDisabled ? "disabled" : ""}>${d}</button>`;
    }
    html += "</div>";
    container.innerHTML = html;

    container.querySelectorAll("[data-cal-nav]").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        const dir = e.currentTarget.dataset.calNav;
        const nd = new Date(state.calendarDate);
        if (dir === "prev") nd.setMonth(nd.getMonth() - 1);
        else nd.setMonth(nd.getMonth() + 1);
        state.calendarDate = nd;
        renderCalendar();
        renderSlots();
      });
    });

    container
      .querySelectorAll(".day:not(.empty):not(.disabled)")
      .forEach((el) => {
        el.addEventListener("click", () => {
          state.selectedDate = el.dataset.date;
          state.selectedTime = null;
          renderCalendar();
          renderSlots();
          updateConfirmUI();
        });
      });
  }

  async function renderSlots() {
    const container = document.getElementById("slotsContainer");
    const doc = getDoctor(state.selectedDoctorId);
    const dateKey = state.selectedDate;
    if (!doc || !dateKey) {
      container.innerHTML =
        '<p style="color:var(--text-muted);padding:16px;">Select a date to see slots.</p>';
      return;
    }

    let booked = [];
    try {
      const url =
        API +
        "?action=get_booked_slots&doctor_id=" +
        doc.id +
        "&date=" +
        encodeURIComponent(dateKey);
      const resp = await fetch(url);
      if (resp.ok) {
        const text = await resp.text();
        try {
          const parsed = JSON.parse(text);
          if (Array.isArray(parsed)) booked = parsed;
        } catch (e) {
          // ignore
        }
      }
    } catch (e) {
      // ignore
    }

    const start = doc.working_hours_start || "09:00";
    const end = doc.working_hours_end || "17:00";
    const duration = parseInt(doc.slot_duration) || 15;
    const slots = [];
    let cur = start;
    while (cur < end) {
      const isBooked = booked.includes(cur);
      slots.push({ time: cur, available: !isBooked, booked: isBooked });
      const [h, m] = cur.split(":").map(Number);
      const total = h * 60 + m + duration;
      const nh = Math.floor(total / 60) % 24;
      const nm = total % 60;
      cur = `${String(nh).padStart(2, "0")}:${String(nm).padStart(2, "0")}`;
    }

    if (slots.length === 0) {
      container.innerHTML =
        '<p style="color:var(--text-muted);padding:16px;">No slots available on this day.</p>';
      return;
    }

    const grid = document.createElement("div");
    grid.className = "slots-grid";
    slots.forEach((slot) => {
      const btn = document.createElement("button");
      btn.className = "slot-btn";
      if (slot.available) btn.classList.add("available");
      else if (slot.booked) btn.classList.add("booked");
      else btn.classList.add("unavailable");
      if (state.selectedTime === slot.time && slot.available)
        btn.classList.add("selected");
      btn.textContent = formatTime(slot.time);
      if (!slot.available) btn.disabled = true;
      else {
        btn.addEventListener("click", () => {
          state.selectedTime = slot.time;
          renderSlots();
          updateStatus("status4", "Done ✓", true);
          markCompleted("container4");
          renderConfirm();
          revealContainer("container5");
          updateConfirmUI();
        });
      }
      grid.appendChild(btn);
    });
    container.innerHTML = "";
    container.appendChild(grid);
  }

  // ── CONFIRM ──────────────────────────
  function renderConfirm() {
    const container = document.getElementById("confirmSummary");
    const doc = getDoctor(state.selectedDoctorId);
    const treatment = state.selectedTreatment;
    if (!doc || !state.selectedDate || !state.selectedTime || !treatment) {
      container.innerHTML =
        '<p style="color:var(--text-muted);">Missing information.</p>';
      return;
    }
    const total = (doc.fee || 0) + (treatment.surgery_fee || 0);
    container.innerHTML = `
                    <div class="row"><span class="label">Specialization</span><span class="value">${getSpecName(treatment.specialization_id)}</span></div>
                    <div class="row"><span class="label">Treatment</span><span class="value">${treatment.name}</span></div>
                    ${treatment.package_name ? `<div class="row"><span class="label">Package</span><span class="value">${treatment.package_name} (${formatCurrency(treatment.package_price || treatment.consult_fee)})</span></div>` : ""}
                    <div class="row"><span class="label">Doctor</span><span class="value">${doc.name}</span></div>
                    <div class="row"><span class="label">Date</span><span class="value">${formatDate(state.selectedDate)}</span></div>
                    <div class="row"><span class="label">Time</span><span class="value">${formatTime(state.selectedTime)}</span></div>
                    <div class="row"><span class="label">Consultation Fee</span><span class="value">${formatCurrency(doc.fee)}</span></div>
                    ${treatment.surgery_fee ? `<div class="row"><span class="label">Surgery Fee</span><span class="value">${formatCurrency(treatment.surgery_fee)}</span></div>` : ""}
                    <div class="row" style="border-top:2px solid var(--primary);padding-top:10px;font-size:1.05rem;"><span class="label">Total Amount</span><span class="value highlight">${formatCurrency(total)}</span></div>
                `;
  }

  function updateConfirmUI() {
    const doc = getDoctor(state.selectedDoctorId);
    const btn = document.getElementById("btnBookNow");
    const terms = document.getElementById("termsCheck").checked;
    const consent = document.getElementById("consentCheck").checked;
    const cancel = document.getElementById("cancelCheck").checked;
    btn.disabled = !(
      doc &&
      state.selectedDate &&
      state.selectedTime &&
      terms &&
      consent &&
      cancel
    );
  }

  function hideContainersAfter(step) {
    for (let i = step + 1; i <= 5; i++) {
      const el = document.getElementById("container" + i);
      if (el) {
        el.classList.remove("visible", "active-step", "completed");
        updateStatus("status" + i, "Pending", false);
      }
    }
    if (step < 5) {
      document.getElementById("btnBookNow").disabled = true;
      document.getElementById("confirmationResult").innerHTML = "";
      document.getElementById("termsCheck").checked = false;
      document.getElementById("privacyCheck").checked = false;
      document.getElementById("consentCheck").checked = false;
      document.getElementById("cancelCheck").checked = false;
    }
  }

  // ── BOOK NOW ─────────────────────────
  async function handleBookNow() {
    const doc = getDoctor(state.selectedDoctorId);
    const treatment = state.selectedTreatment;
    if (!doc || !state.selectedDate || !state.selectedTime || !treatment)
      return;

    const btn = document.getElementById("btnBookNow");
    btn.disabled = true;
    btn.textContent = "Booking...";

    try {
      const url = API + "?action=book_appointment";
      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          doctor_id: doc.id,
          treatment_id: treatment.id,
          date: state.selectedDate,
          time: state.selectedTime,
          reason: treatment.name,
        }),
      });
      const text = await response.text();
      console.log("Server response:", text);
      let result;
      try {
        result = JSON.parse(text);
      } catch (e) {
        showToast("❌ Server error: " + text.substring(0, 100), true);
        btn.disabled = false;
        btn.textContent = "BOOK NOW";
        return;
      }
      if (!response.ok) {
        throw new Error(result.error || "Booking failed");
      }

      // Success
      updateStatus("status5", "Booked ✓", true);
      markCompleted("container5");
      btn.disabled = true;
      btn.textContent = "✓ Booked!";
      document.getElementById("confirmationResult").innerHTML = `
      <div style="background:#f0fdf4;border-radius:16px;padding:20px 24px;border:2px solid #86efac;margin-top:12px;">
        <h4 style="color:var(--green);margin-bottom:12px;"><i class="fas fa-check-circle"></i> Appointment Confirmed!</h4>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px 16px;font-size:0.85rem;">
          <div><strong>Appointment ID:</strong> #${result.appointment_id}</div>
          <div><strong>Doctor:</strong> ${doc.name}</div>
          <div><strong>Treatment:</strong> ${treatment.name}</div>
          <div><strong>Date:</strong> ${formatDate(state.selectedDate)}</div>
          <div><strong>Time:</strong> ${formatTime(state.selectedTime)}</div>
          <div><strong>Amount:</strong> ${formatCurrency((doc.fee || 0) + (treatment.surgery_fee || 0))}</div>
          <div><strong>Status:</strong> <span style="color:var(--green);font-weight:700;">Confirmed</span></div>
        </div>
        <button onclick="window.print()" style="margin-top:12px;padding:8px 18px;border-radius:20px;border:2px solid var(--primary);background:transparent;cursor:pointer;font-weight:600;font-size:0.8rem;"><i class="fas fa-print"></i> Print Appointment</button>
      </div>
    `;
      showToast(`✅ Booking confirmed! ID: #${result.appointment_id}`);
    } catch (err) {
      showToast("❌ " + err.message, true);
      btn.disabled = false;
      btn.textContent = "BOOK NOW";
    }
  }

  // ── REVEAL CONTAINER ─────────────────
  function revealContainer(id) {
    const el = document.getElementById(id);
    if (!el) return;
    el.classList.add("visible");
    el.classList.add("active-step");
    setTimeout(() => {
      el.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 150);
  }

  function markCompleted(id) {
    const el = document.getElementById(id);
    if (el) {
      el.classList.add("completed");
      el.classList.remove("active-step");
    }
  }

  function updateStatus(id, text, done) {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent = text;
    el.className = "container-status " + (done ? "done" : "pending");
  }

  // ── TOAST ────────────────────────────
  let toastTimeout;

  function showToast(msg, isError = false) {
    const el = document.getElementById("toast");
    document.getElementById("toastMessage").textContent = msg;
    el.className = "toast" + (isError ? " error" : "");
    el.classList.add("show");
    clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => el.classList.remove("show"), 4000);
  }

  async function init() {
    await loadAllData();
    document.getElementById("container1").classList.add("visible");
    document
      .getElementById("btnBookNow")
      .addEventListener("click", handleBookNow);
    document
      .querySelectorAll('.terms-section input[type="checkbox"]')
      .forEach((cb) => {
        cb.addEventListener("change", updateConfirmUI);
      });
  }

  document.addEventListener("DOMContentLoaded", init);
})();
