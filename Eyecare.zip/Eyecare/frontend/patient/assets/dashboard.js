// ─── AOS init (light, elegant) ──────────────────────────────
AOS.init({
  once: true,
  duration: 600,
  easing: "ease-out-cubic",
  offset: 30,
  disable: window.innerWidth < 768,
});

// ─── SIDEBAR state ────────────────────────────────────────────
const sidebar = document.getElementById("sidebar");
const mainEl = document.getElementById("mainContent");
const toggleBtn = document.getElementById("sidebarToggle");

// default: collapsed (mini) – but we want it mini, not expanded
// we rely on CSS :hover to expand

// toggle on click – expand permanently
toggleBtn.addEventListener("click", (e) => {
  e.stopPropagation();
  sidebar.classList.toggle("expanded");
  // store preference
  localStorage.setItem(
    "sidebarExpanded",
    sidebar.classList.contains("expanded") ? "true" : "false",
  );
});

// restore preference
if (localStorage.getItem("sidebarExpanded") === "true") {
  sidebar.classList.add("expanded");
}

// ─── LOGOUT ────────────────────────────────────────────────────
document.getElementById("logoutBtn").addEventListener("click", () => {
  if (typeof logout === "function") {
    logout();
  } else {
    window.location.href = "../login.html";
  }
});

// ─── DASHBOARD DATA LOAD ─────────────────────────────────────
document.addEventListener("DOMContentLoaded", loadDashboard);

async function loadDashboard() {
  try {
    const response = await fetch(
      "http://localhost/Eyecare/backend/patient_dashboard.php",
    );
    if (!response.ok) {
      if (response.status === 401) {
        window.location.href = "../login.html";
        return;
      }
      throw new Error("Failed to load dashboard data");
    }
    const data = await response.json();
    console.log("Dashboard data:", data);

    // 1. initials & greeting
    const nameParts = data.user.full_name.trim().split(/\s+/);
    let initials = nameParts[0] ? nameParts[0][0] : "";
    if (nameParts.length > 1) initials += nameParts[nameParts.length - 1][0];
    initials = initials.toUpperCase();

    const hour = new Date().getHours();
    let greeting = "Good morning";
    if (hour >= 12 && hour < 17) greeting = "Good afternoon";
    else if (hour >= 17) greeting = "Good evening";

    document.getElementById("sidebar-user-avatar").textContent = initials;
    document.getElementById("topbar-avatar").textContent = initials;
    document.getElementById("profile-avatar").textContent = initials;

    document.getElementById("greeting-text").textContent = greeting + " 👋";
    document.getElementById("welcome-user-name").textContent = nameParts[0];

    const options = {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric",
    };
    document.getElementById("topbar-date").textContent =
      new Date().toLocaleDateString("en-GB", options);

    // 2. stats
    document.getElementById("stat-value-total").textContent =
      data.stats.total || 0;
    document.getElementById("stat-value-upcoming").textContent =
      data.stats.upcoming_count || 0;
    document.getElementById("stat-value-prescriptions").textContent =
      data.stats.rx_count || 0;

    if (data.last_visit) {
      const lastVisitDate = new Date(data.last_visit);
      document.getElementById("stat-value-last-visit").textContent =
        lastVisitDate.toLocaleDateString("en-GB", {
          day: "2-digit",
          month: "short",
        });
      document.getElementById("stat-sub-last-visit").textContent =
        lastVisitDate.getFullYear();
    } else {
      document.getElementById("stat-value-last-visit").textContent = "—";
      document.getElementById("stat-sub-last-visit").textContent =
        "No completed visits";
    }

    // 3. profile
    document.getElementById("sidebar-user-name").textContent =
      data.user.full_name;
    document.getElementById("profile-user-name").textContent =
      data.user.full_name;
    document.getElementById("profile-email").textContent = data.user.email;
    document.getElementById("profile-phone").textContent =
      data.user.phone || "—";
    document.getElementById("profile-gender").textContent =
      data.user.gender || "—";

    if (data.user.dob) {
      const dobDate = new Date(data.user.dob);
      document.getElementById("profile-dob").textContent =
        dobDate.toLocaleDateString("en-GB", {
          day: "2-digit",
          month: "short",
          year: "numeric",
        });
    } else {
      document.getElementById("profile-dob").textContent = "—";
    }

    // 4. next appointment
    const nextCard = document.getElementById("next-appt-card-content");
    const noAppt = document.getElementById("no-appt-content");

    if (data.next_appointment) {
      nextCard.style.display = "block";
      noAppt.style.display = "none";

      const nextDate = new Date(data.next_appointment.appointment_date);
      document.getElementById("next-appt-date").textContent =
        nextDate.toLocaleDateString("en-GB", {
          weekday: "long",
          day: "numeric",
          month: "long",
          year: "numeric",
        });

      let timeStr = "Time TBD";
      if (data.next_appointment.start_time) {
        const [hh, mm] = data.next_appointment.start_time.split(":");
        const dummyDate = new Date();
        dummyDate.setHours(parseInt(hh), parseInt(mm));
        timeStr =
          "🕐 " +
          dummyDate.toLocaleTimeString("en-US", {
            hour: "2-digit",
            minute: "2-digit",
          });
      }
      document.getElementById("next-appt-time").innerHTML =
        timeStr +
        " &nbsp;·&nbsp; " +
        (data.next_appointment.type || "Check-up");
      document.getElementById("next-appt-doctor-name").textContent =
        data.next_appointment.provider_name || "To be assigned";
    } else {
      nextCard.style.display = "none";
      noAppt.style.display = "block";
    }

    // 5. appointments table
    const table = document.getElementById("appointments-table");
    const empty = document.getElementById("appointments-empty-state");
    const tbody = document.getElementById("appointments-table-body");
    const countBadge = document.getElementById("appointments-records-count");

    if (data.recent_appointments && data.recent_appointments.length > 0) {
      table.style.display = "table";
      empty.style.display = "none";
      countBadge.style.display = "inline-block";
      countBadge.textContent = data.recent_appointments.length + " records";

      tbody.innerHTML = data.recent_appointments
        .map((appt) => {
          const apptDate = new Date(appt.appointment_date);
          const dateStr = apptDate.toLocaleDateString("en-GB", {
            day: "2-digit",
            month: "short",
            year: "numeric",
          });
          let timeStr = "";
          if (appt.start_time) {
            const [hh, mm] = appt.start_time.split(":");
            const d = new Date();
            d.setHours(parseInt(hh), parseInt(mm));
            timeStr = d.toLocaleTimeString("en-US", {
              hour: "2-digit",
              minute: "2-digit",
            });
          }
          return `
                <tr>
                  <td>
                    <div class="date-cell">${dateStr}</div>
                    <div class="doc-cell">${timeStr}</div>
                  </td>
                  <td>${appt.provider_name || "N/A"}</td>
                  <td>${appt.type || "General"}</td>
                  <td>${getStatusBadge(appt.status || "Pending")}</td>
                </tr>
              `;
        })
        .join("");
    } else {
      table.style.display = "none";
      empty.style.display = "block";
      countBadge.style.display = "none";
    }
  } catch (error) {
    console.error("Error loading dashboard data:", error);
  }
}

function getStatusBadge(status) {
  const map = {
    Confirmed: ["#d1fae5", "#065f46", "✓"],
    Pending: ["#fef3c7", "#92400e", "⏳"],
    Completed: ["#dbeafe", "#1e40af", "✔"],
    Cancelled: ["#fee2e2", "#991b1b", "✕"],
  };
  const [bg, color, icon] = map[status] || ["#f3f4f6", "#374151", "•"];
  return `<span class="status-badge" style="background:${bg};color:${color};">${icon} ${status}</span>`;
}
