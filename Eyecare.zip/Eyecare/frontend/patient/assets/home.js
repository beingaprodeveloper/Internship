// frontend/patient/assets/home.js
// EyeCare Appointment Booking System - Complete JavaScript

// ============================================================
// STATE MANAGEMENT
// ============================================================

const state = {
  selectedSpecialization: null,
  selectedTreatment: null,
  selectedDoctor: null,
  selectedDate: null,
  selectedTime: null,
  currentStep: 1,
  apiData: null,
  doctors: [],
  specializations: [],
  bookings: [],
};

// ============================================================
// API ENDPOINTS - UPDATED
// ============================================================

// In home.js, update the AUTH endpoint:
const API = {
  BASE: "../../backend/",
  AUTH: "../../backend/auth_check.php", // This is correct
  DOCTORS: "../../backend/auth_get_dashboard.php",
  BOOKING: "../../backend/patient_booking-api.php", // ← make sure this matches the actual filename
  DASHBOARD: "../../backend/auth_get_dashboard.php",
  SLOTS: "../../backend/patient_getslots.php", // ← change to new name
};

// ============================================================
// AUTHENTICATION CHECK - UPDATED WITH CREDENTIALS
// ============================================================

async function checkAuth() {
  try {
    console.log("Checking authentication with backend...");
    const response = await fetch(API.AUTH, {
      method: "GET",
      credentials: "same-origin", // Added for session cookies
      headers: {
        "Content-Type": "application/json",
      },
    });

    const data = await response.json();
    console.log("Auth response:", data);

    if (data.status === "success") {
      console.log("User authenticated:", data.user);
      return data;
    } else {
      console.log("Auth failed, redirecting to login");
      window.location.href = "../../login.html";
      return false;
    }
  } catch (error) {
    console.error("Auth check failed:", error);
    window.location.href = "../../login.html";
    return false;
  }
}

// ============================================================
// DATE
// ============================================================

async function selectDate(dateStr) {
  state.selectedDate = dateStr;
  document.getElementById("status4").textContent = "In Progress";
  document.getElementById("status4").className = "container-status in-progress";

  // Highlight selected date
  document.querySelectorAll(".calendar-day").forEach((el) => {
    el.style.background = el.dataset.date === dateStr ? "var(--gold)" : "";
    el.style.color = el.dataset.date === dateStr ? "#fff" : "";
  });

  // Fetch slots from backend
  await fetchSlots(dateStr);
}

async function fetchSlots(dateStr) {
  const container = document.getElementById("slotsContainer");
  if (!container) return;

  const doctorId = state.selectedDoctor?.id;
  if (!doctorId) {
    container.innerHTML =
      '<p style="color:var(--text-muted);">Please select a doctor first.</p>';
    return;
  }

  try {
    const response = await fetch(
      `${API.SLOTS}?doctor_id=${doctorId}&date=${dateStr}`,
    );
    const result = await response.json();

    if (result.status === "success") {
      renderTimeSlots(result.data);
    } else {
      throw new Error(result.message || "Failed to load slots");
    }
  } catch (error) {
    console.error("Error fetching slots:", error);
    container.innerHTML =
      '<p style="color:var(--text-muted);">Error loading slots. Please try again.</p>';
  }
}

// ============================================================
// INITIALIZATION
// ============================================================

document.addEventListener("DOMContentLoaded", async () => {
  console.log("Home page loading...");

  // Check authentication FIRST
  const auth = await checkAuth();
  if (!auth) {
    console.log("Authentication failed, stopping execution");
    return;
  }

  console.log("Authentication successful, loading page content...");

  // Load data
  await loadData();

  // Set up term checkboxes
  ["termsCheck", "privacyCheck", "consentCheck", "cancelCheck"].forEach(
    (id) => {
      const el = document.getElementById(id);
      if (el) {
        el.addEventListener("change", checkTerms);
      }
    },
  );

  // Book now button
  const bookBtn = document.getElementById("btnBookNow");
  if (bookBtn) {
    bookBtn.addEventListener("click", confirmBooking);
  }

  // Doctor popup close
  const popupClose = document.getElementById("popupClose");
  if (popupClose) {
    popupClose.addEventListener("click", () => {
      document.getElementById("doctorPopup").style.display = "none";
    });
  }

  // Close popup on overlay click
  document.getElementById("doctorPopup").addEventListener("click", (e) => {
    if (e.target === e.currentTarget) {
      e.currentTarget.style.display = "none";
    }
  });

  // Hero stats animation
  animateStats();

  console.log("Home page fully loaded");
});

// ============================================================
// LOAD DATA FROM API - UNCHANGED
// ============================================================

async function loadData() {
  try {
    const response = await fetch(API.DOCTORS);
    if (!response.ok) throw new Error("Failed to fetch data");

    const data = await response.json();
    console.log("Data loaded:", data);

    // The data structure might be different, adapt accordinglyF
    if (data.status === "success" && data.data) {
      state.apiData = data.data;
      state.doctors = data.data.doctors || [];
      state.specializations = data.data.specializations || [];
      renderSpecializations();
    } else {
      // Fallback to mock data for demo
      state.specializations = [
        {
          id: 1,
          label: "Cataract",
          icon: "👁️",
          treatments: [
            { id: 1, name: "Cataract Surgery", consult_fee: 500, duration: 60 },
          ],
        },
        {
          id: 2,
          label: "LASIK",
          icon: "👓",
          treatments: [
            { id: 2, name: "LASIK Surgery", consult_fee: 800, duration: 45 },
          ],
        },
        {
          id: 3,
          label: "Glaucoma",
          icon: "🟢",
          treatments: [
            {
              id: 3,
              name: "Glaucoma Treatment",
              consult_fee: 400,
              duration: 30,
            },
          ],
        },
        {
          id: 4,
          label: "Retina",
          icon: "🔴",
          treatments: [
            { id: 4, name: "Retina Surgery", consult_fee: 600, duration: 50 },
          ],
        },
      ];
      state.doctors = [
        {
          id: 1,
          name: "Dr. Smith",
          specialization: "Cataract",
          fee: 500,
          availableToday: true,
          rating: 4.8,
          experience: "15 years",
        },
        {
          id: 2,
          name: "Dr. Johnson",
          specialization: "LASIK",
          fee: 800,
          availableToday: true,
          rating: 4.9,
          experience: "12 years",
        },
      ];
      renderSpecializations();
    }

    return data;
  } catch (error) {
    console.error("Error loading data:", error);
    showToast("Failed to load doctor data. Please refresh.", "error");
    return null;
  }
}

// ============================================================
// UTILITY FUNCTIONS - UNCHANGED
// ============================================================

function showToast(message, type = "success") {
  const toast = document.getElementById("toast");
  const toastMessage = document.getElementById("toastMessage");
  const icon = toast.querySelector("i");

  toastMessage.textContent = message;
  toast.className = "toast";

  if (type === "success") {
    icon.className = "fas fa-check-circle";
    toast.style.borderLeftColor = "#22c55e";
  } else if (type === "error") {
    icon.className = "fas fa-exclamation-circle";
    toast.style.borderLeftColor = "#dc2626";
  } else {
    icon.className = "fas fa-info-circle";
    toast.style.borderLeftColor = "#3b82f6";
  }

  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 4000);
}

function formatDate(dateStr) {
  const date = new Date(dateStr + "T00:00:00");
  return date.toLocaleDateString("en-US", {
    weekday: "short",
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

function formatTime(timeStr) {
  if (!timeStr) return "";
  const [hours, minutes] = timeStr.split(":");
  const hour = parseInt(hours);
  const ampm = hour >= 12 ? "PM" : "AM";
  const hour12 = hour % 12 || 12;
  return `${hour12}:${minutes} ${ampm}`;
}

function renderTimeSlots(slotsData) {
  const container = document.getElementById("slotsContainer");
  if (!container) return;

  if (!slotsData || slotsData.length === 0) {
    container.innerHTML =
      '<p style="color:var(--text-muted);">No slots available for this date.</p>';
    return;
  }

  let html =
    '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;">';

  slotsData.forEach((slot) => {
    const time = slot.time;
    const isBooked = slot.booked;
    const isSelected = state.selectedTime === time;

    html += `
      <div class="slot-item ${isBooked ? "booked" : ""} ${isSelected ? "selected" : ""}"
           data-time="${time}"
           style="padding:10px;border-radius:8px;text-align:center;font-size:0.85rem;font-weight:500;cursor:${isBooked ? "default" : "pointer"};
                  background:${isSelected ? "var(--gold)" : isBooked ? "var(--border)" : "var(--emerald-soft)"};
                  color:${isSelected ? "#fff" : isBooked ? "var(--text-muted)" : "var(--text-primary)"};
                  border:2px solid ${isSelected ? "var(--gold)" : "transparent"};
                  transition:all 0.2s ease;"
           onclick="${isBooked ? "" : `selectTime('${time}')`}">
        ${formatTime(time)}
        ${isBooked ? '<span style="display:block;font-size:0.6rem;color:var(--text-muted);">Booked</span>' : ""}
      </div>
    `;
  });

  html += "</div>";
  container.innerHTML = html;
}

function generateBookingReference() {
  const prefix = "PB";
  const date = new Date();
  const dateStr =
    date.getFullYear() +
    String(date.getMonth() + 1).padStart(2, "0") +
    String(date.getDate()).padStart(2, "0");
  const random = Math.random().toString(36).substring(2, 8).toUpperCase();
  return `${prefix}-${dateStr}-${random}`;
}

function calculateEndTime(startTime, duration) {
  const [hours, minutes] = startTime.split(":").map(Number);
  const totalMinutes = hours * 60 + minutes + duration;
  const endHours = Math.floor(totalMinutes / 60);
  const endMinutes = totalMinutes % 60;
  return `${String(endHours).padStart(2, "0")}:${String(endMinutes).padStart(2, "0")}:00`;
}

// ============================================================
// RENDER FUNCTIONS - UNCHANGED
// ============================================================
function renderSpecializations() {
  const grid = document.getElementById("specGrid");
  if (!grid) return;

  grid.innerHTML = "";

  if (!state.specializations || state.specializations.length === 0) {
    grid.innerHTML =
      '<p style="grid-column:1/-1;text-align:center;color:var(--text-muted);">No specializations available</p>';
    return;
  }

  state.specializations.forEach((spec, index) => {
    const card = document.createElement("div");
    card.className = "option-card";
    card.dataset.index = index;
    card.setAttribute("role", "radio");
    card.setAttribute("aria-checked", "false");
    card.tabIndex = 0;

    // ✅ SIMPLIFIED: only icon + name
    card.innerHTML = `
      <div class="option-icon">${spec.icon || "👁️"}</div>
      <div class="option-name">${spec.label}</div>
    `;

    card.addEventListener("click", () => selectSpecialization(index));
    card.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        selectSpecialization(index);
      }
    });

    grid.appendChild(card);
  });
}

function selectSpecialization(index) {
  const spec = state.specializations[index];
  if (!spec) return;

  document.querySelectorAll("#specGrid .option-card").forEach((card, i) => {
    card.classList.toggle("selected", i === index);
    card.setAttribute("aria-checked", i === index);
  });

  state.selectedSpecialization = spec;
  state.selectedTreatment = null;
  state.selectedDoctor = null;
  state.selectedDate = null;
  state.selectedTime = null;

  document.getElementById("status1").textContent = "Completed";
  document.getElementById("status1").className = "container-status completed";

  renderTreatments(spec.treatments || []);
  showContainer("container2"); // <-- ADD THIS LINE
  document
    .getElementById("container2")
    .scrollIntoView({ behavior: "smooth", block: "start" });
}

function renderTreatments(treatments) {
  const grid = document.getElementById("treatmentGrid");
  if (!grid) return;
  grid.innerHTML = "";

  if (!treatments || treatments.length === 0) {
    grid.innerHTML =
      '<p style="grid-column:1/-1;text-align:center;color:var(--text-muted);">No treatments available</p>';
    return;
  }

  treatments.forEach((treatment, index) => {
    // Parse package_includes if it's a JSON string
    let includes = [];
    if (treatment.package_includes) {
      try {
        includes =
          typeof treatment.package_includes === "string"
            ? JSON.parse(treatment.package_includes)
            : treatment.package_includes;
      } catch (e) {
        includes = [];
      }
    }
    // Ensure includes is an array
    if (!Array.isArray(includes)) includes = [];

    const price = treatment.consult_fee || treatment.package_price || 0;
    const duration = treatment.duration || 30;
    const recovery = treatment.recovery || "Varies";

    // Build the card
    const card = document.createElement("div");
    card.className = "treatment-card";
    card.dataset.index = index;

    let html = `
      <div class="treatment-header">
        <span class="treatment-name">${treatment.name}</span>
        <span class="treatment-price">$${price.toFixed(2)}</span>
      </div>
      <div class="treatment-desc">${treatment.description || "No description available"}</div>
      <div class="treatment-meta">
        <span><i class="fas fa-clock"></i> ${duration} mins</span>
        <span><i class="fas fa-money-bill-wave"></i> Consult: $${price}</span>
        <span><i class="fas fa-heartbeat"></i> Recovery: ${recovery}</span>
      </div>
    `;

    // Package section (if package_name exists)
    if (treatment.package_name) {
      html += `
        <div class="package-section">
          <div class="package-name">${treatment.package_name}</div>
          <div class="package-includes">
            ${includes.map((item) => `<span><i class="fas fa-check-circle"></i> ${item}</span>`).join("")}
          </div>
          <button class="btn-select-package" data-index="${index}">Select Package</button>
        </div>
      `;
    }

    card.innerHTML = html;
    grid.appendChild(card);

    // Attach click event to the whole card (optional)
    card.addEventListener("click", (e) => {
      // If the click is on the button, we'll let the button handle it separately.
      if (e.target.closest(".btn-select-package")) return;
      selectTreatment(index, treatments);
    });

    // Attach click event to the "Select Package" button
    const pkgBtn = card.querySelector(".btn-select-package");
    if (pkgBtn) {
      pkgBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        selectTreatment(index, treatments);
      });
    }
  });
}

function selectTreatment(index, treatments) {
  const treatment = treatments[index];
  if (!treatment) return;

  document
    .querySelectorAll("#treatmentGrid .treatment-card")
    .forEach((card, i) => {
      card.classList.toggle("selected", i === index);
    });

  state.selectedTreatment = treatment;
  document.getElementById("status2").textContent = "Completed";
  document.getElementById("status2").className = "container-status completed";

  showContainer("container3"); // <-- ADD THIS LINE

  // Use the doctors from state (already loaded)
  const doctors = state.doctors || [];
  renderDoctors(doctors);
  document
    .getElementById("container3")
    .scrollIntoView({ behavior: "smooth", block: "start" });
}

function renderDoctors(doctors) {
  const grid = document.getElementById("doctorGrid");
  if (!grid) return;
  grid.innerHTML = "";

  if (!doctors || doctors.length === 0) {
    grid.innerHTML =
      '<p style="grid-column:1/-1;text-align:center;color:var(--text-muted);">No doctors available</p>';
    return;
  }

  doctors.forEach((doctor, index) => {
    const card = document.createElement("div");
    card.className = "doctor-card";
    card.dataset.index = index;

    // Rating stars
    const rating = doctor.rating || 4.5;
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    let starsHtml = "";
    for (let i = 0; i < fullStars; i++)
      starsHtml += '<i class="fas fa-star"></i>';
    if (hasHalfStar) starsHtml += '<i class="fas fa-star-half-alt"></i>';
    for (let i = fullStars + (hasHalfStar ? 1 : 0); i < 5; i++)
      starsHtml += '<i class="far fa-star"></i>';

    // Avatar: use photo if available, else initials
    const avatarContent = doctor.photo
      ? `<img src="${doctor.photo}" alt="${doctor.name}" class="doctor-avatar-img" />`
      : `<span class="doctor-avatar-initials">${doctor.name.charAt(0)}</span>`;

    card.innerHTML = `
      <div class="doctor-avatar-wrapper">
        <div class="doctor-avatar">${avatarContent}</div>
        <span class="doctor-status ${doctor.availableToday ? "available" : "unavailable"}"></span>
        ${doctor.availableToday ? '<span class="badge-available">Available Today</span>' : ""}
      </div>
      <div class="doctor-info">
        <div class="doctor-name">${doctor.name}</div>
        <div class="doctor-specialization">${doctor.specialization || "General"}</div>
        <div class="doctor-rating">
          ${starsHtml}
          <span class="rating-number">${rating.toFixed(1)}</span>
          <span class="rating-experience">(${doctor.experience || "0 years"})</span>
        </div>
        <div class="doctor-fee">
          <i class="fas fa-money-bill-wave"></i> $${doctor.fee || 0} consultation fee
        </div>
      </div>
      <button class="btn-select-doctor" data-index="${index}">Select Doctor</button>
    `;

    // Click on card or button
    const select = () => selectDoctor(index, doctors);
    card.addEventListener("click", select);
    const btn = card.querySelector(".btn-select-doctor");
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      select();
    });

    grid.appendChild(card);
  });
}

function selectDoctor(index, doctors) {
  const doctor = doctors[index];
  if (!doctor) return;

  document.querySelectorAll("#doctorGrid .doctor-card").forEach((card, i) => {
    card.classList.toggle("selected", i === index);
  });

  state.selectedDoctor = doctor;
  document.getElementById("status3").textContent = "Completed";
  document.getElementById("status3").className = "container-status completed";

  showContainer("container4"); // <-- ADD THIS LINE
  renderCalendar();
  document
    .getElementById("container4")
    .scrollIntoView({ behavior: "smooth", block: "start" });

  console.log("Selected doctor:", doctor);
}

function renderCalendar() {
  const container = document.getElementById("calendarContainer");
  if (!container) return;

  const today = new Date();
  const currentMonth = today.getMonth();
  const currentYear = today.getFullYear();

  let html = `
        <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:6px;text-align:center;font-weight:600;font-size:0.75rem;color:var(--text-muted);margin-bottom:8px;">
            <span>Sun</span><span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span>
        </div>
        <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:6px;">
    `;

  const firstDay = new Date(currentYear, currentMonth, 1).getDay();

  for (let i = 0; i < firstDay; i++) {
    html += `<div style="padding:8px;"></div>`;
  }

  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();

  for (let day = 1; day <= daysInMonth; day++) {
    const date = new Date(currentYear, currentMonth, day);
    const dateStr = date.toISOString().split("T")[0];
    const isPast = date < today;
    const isToday = date.toDateString() === today.toDateString();
    const isAvailable =
      !isPast && state.selectedDoctor && state.selectedDoctor.availableToday;

    html += `
            <div class="calendar-day ${isToday ? "today" : ""} ${isAvailable ? "available" : "unavailable"}" 
                 data-date="${dateStr}"
                 style="padding:8px 4px;border-radius:8px;cursor:${isAvailable ? "pointer" : "default"};text-align:center;font-size:0.85rem;font-weight:500;
                        ${isPast ? "color:var(--text-muted);opacity:0.4;" : ""}
                        ${isToday ? "background:var(--gold);color:#fff;" : ""}
                        ${isAvailable && !isToday ? "background:var(--emerald-soft);" : ""}"
                 onclick="${isAvailable ? `selectDate('${dateStr}')` : ""}">
                ${day}
            </div>
        `;
  }

  html += `</div>`;
  container.innerHTML = html;
}

async function selectDate(dateStr) {
  state.selectedDate = dateStr;
  document.getElementById("status4").textContent = "In Progress";
  document.getElementById("status4").className = "container-status in-progress";

  document.querySelectorAll(".calendar-day").forEach((el) => {
    el.style.background = el.dataset.date === dateStr ? "var(--gold)" : "";
    el.style.color = el.dataset.date === dateStr ? "#fff" : "";
  });

  await fetchSlots(dateStr);
}

function selectTime(time) {
  state.selectedTime = time;
  document.getElementById("status4").textContent = "Completed";
  document.getElementById("status4").className = "container-status completed";

  // Highlight the selected slot
  document.querySelectorAll(".slot-item").forEach((el) => {
    el.style.background = el.dataset.time === time ? "var(--gold)" : "";
    el.style.color = el.dataset.time === time ? "#fff" : "";
    el.style.borderColor =
      el.dataset.time === time ? "var(--gold)" : "transparent";
  });

  // 🔥 ADD THIS LINE – makes container5 visible
  showContainer("container5");

  updateSummary();
  document
    .getElementById("container5")
    .scrollIntoView({ behavior: "smooth", block: "start" });
}

function updateSummary() {
  const container = document.getElementById("confirmSummary");
  if (!container) return;

  const spec = state.selectedSpecialization;
  const treatment = state.selectedTreatment;
  const doctor = state.selectedDoctor;

  if (
    !spec ||
    !treatment ||
    !doctor ||
    !state.selectedDate ||
    !state.selectedTime
  ) {
    container.innerHTML =
      '<p style="color:var(--text-muted);">Please complete all steps to see your booking summary.</p>';
    return;
  }

  const totalFee =
    treatment.consult_fee || treatment.package_price || doctor.fee || 0;
  const bookingRef = generateBookingReference();

  container.innerHTML = `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px;">
      <div><strong>Specialization:</strong> ${spec.label}</div>
      <div><strong>Treatment:</strong> ${treatment.name}</div>
      <div><strong>Doctor:</strong> ${doctor.name}</div>
      <div><strong>Date:</strong> ${formatDate(state.selectedDate)}</div>
      <div><strong>Time:</strong> ${formatTime(state.selectedTime)}</div>
      <div><strong>Duration:</strong> ${treatment.duration || 30} mins</div>
      <div><strong>Fee:</strong> $${totalFee.toFixed(2)}</div>
      <div><strong>Booking Reference:</strong> ${bookingRef}</div>
    </div>
    <div style="padding:12px;background:var(--emerald-soft);border-radius:8px;color:var(--emerald);font-size:0.85rem;">
      <i class="fas fa-info-circle"></i> A confirmation email will be sent to your registered email address.
    </div>
    <!-- ✅ Preview Button -->
    <div style="margin-top:16px; display:flex; gap:12px; justify-content:center; flex-wrap:wrap;">
      <button onclick="showPreviewLetter()" class="btn-letter-preview" style="border:2px solid var(--gold); color:var(--gold-dark); background:transparent; padding:10px 24px; border-radius:30px; font-weight:600; cursor:pointer; transition:0.2s; font-family:var(--font);">
        <i class="fas fa-file-alt"></i> Preview Appointment Letter
      </button>
    </div>
  `;

  state.bookingRef = bookingRef;
  checkTerms();
}

function checkTerms() {
  const terms = document.getElementById("termsCheck");
  const privacy = document.getElementById("privacyCheck");
  const consent = document.getElementById("consentCheck");
  const cancel = document.getElementById("cancelCheck");
  const btn = document.getElementById("btnBookNow");

  if (terms && privacy && consent && cancel && btn) {
    btn.disabled = !(
      terms.checked &&
      privacy.checked &&
      consent.checked &&
      cancel.checked
    );
  }
}

// ============================================================
// CONTAINER VISIBILITY HELPER
// ============================================================

function showContainer(containerId) {
  const container = document.getElementById(containerId);
  if (container) {
    container.classList.add("visible");
    container.classList.add("active-step");
  }
}

// ============================================================
// BOOKING CONFIRMATION - UNCHANGED
// ============================================================

async function confirmBooking() {
  const btn = document.getElementById("btnBookNow");
  btn.disabled = true;
  btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Booking...';

  // ----- DEBUG: Log all state values -----
  console.log("=== STATE DEBUG ===");
  console.log("selectedDoctor:", state.selectedDoctor);
  console.log("selectedDate:", state.selectedDate);
  console.log("selectedTime:", state.selectedTime);
  console.log("selectedTreatment:", state.selectedTreatment);
  console.log("selectedSpecialization:", state.selectedSpecialization);

  try {
    const bookingData = {
      provider_id: state.selectedDoctor?.id,
      appointment_date: state.selectedDate,
      start_time: state.selectedTime,
      end_time: calculateEndTime(
        state.selectedTime,
        state.selectedTreatment?.duration || 30,
      ),
      appointment_type: state.selectedTreatment?.name || "General Checkup",
      reason: `${state.selectedTreatment?.name || "Consultation"} with ${state.selectedDoctor?.name || "Doctor"}`,
      is_premium: true,
      service_id: state.selectedTreatment?.id || null,
      service_name: state.selectedTreatment?.name || "General Consultation",
    };

    console.log("Sending booking data:", bookingData); // ← now shows the object

    const response = await fetch(API.BOOKING, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(bookingData),
    });

    console.log("Response status:", response.status);
    if (!response.ok) {
      // ----- NEW: Read the response body to see the error message -----
      const errorText = await response.text();
      console.error("Server error response:", errorText);
      throw new Error(`HTTP error! status: ${response.status} - ${errorText}`);
    }

    const result = await response.json();
    console.log("Booking response:", result);

    if (result.status === "success") {
      document.getElementById("status5").textContent = "Confirmed";
      document.getElementById("status5").className =
        "container-status completed";

      showToast("Booking confirmed successfully! Check your email.", "success");

      const resultDiv = document.getElementById("confirmationResult");
      resultDiv.innerHTML = `
    <div style="padding:20px;background:var(--emerald-soft);border-radius:12px;border-left:4px solid var(--emerald);">
      <h4 style="color:var(--emerald);margin-bottom:8px;">✅ Booking Confirmed!</h4>
      <p>Reference: <strong>${state.bookingRef || generateBookingReference()}</strong></p>
      <p style="font-size:0.85rem;color:var(--text-muted);">You will receive a confirmation email shortly.</p>
      <div style="margin-top:16px; display:flex; gap:12px; flex-wrap:wrap; justify-content:center;">
        <!-- View Actual Letter Button -->
        <button onclick="viewActualLetter(${result.appointment_id})" class="btn btn-gold" style="background:var(--gradient-gold); color:var(--text-primary); padding:12px 28px; border-radius:30px; border:none; font-weight:700; cursor:pointer; box-shadow:0 4px 16px var(--gold-glow); font-family:var(--font);">
          <i class="fas fa-file-pdf"></i> View Appointment Letter
        </button>
        <a href="dashboard.html" class="btn btn-hero-primary" style="display:inline-block;margin-top:0;padding:10px 24px;border-radius:30px;text-decoration:none;color:#fff;background:var(--gradient-wine);">
          <i class="fas fa-arrow-right"></i> Go to Dashboard
        </a>
      </div>
    </div>
  `;

      btn.innerHTML = '<i class="fas fa-check-circle"></i> Booked!';
    } else {
      showToast(result.message || "Booking failed.", "error");
      btn.disabled = false;
      btn.innerHTML = '<i class="fas fa-check-circle"></i> BOOK NOW';
    }
  } catch (error) {
    console.error("Booking error:", error);
    showToast(`Error: ${error.message}`, "error");
    btn.disabled = false;
    btn.innerHTML = '<i class="fas fa-check-circle"></i> BOOK NOW';
  }
}

function formatDate(dateStr) {
  const d = new Date(dateStr + "T00:00:00");
  return d.toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

// ============================================================
// HERO STATS ANIMATION - UNCHANGED
// ============================================================

function animateStats() {
  const statNumbers = document.querySelectorAll(".stat-number");

  statNumbers.forEach((stat) => {
    const target = parseInt(stat.dataset.count);
    if (!target) return;

    let current = 0;
    const increment = Math.ceil(target / 50);
    const duration = 1500;
    const interval = duration / 50;

    const timer = setInterval(() => {
      current += increment;
      if (current >= target) {
        current = target;
        clearInterval(timer);
      }
      stat.textContent = current;
    }, interval);
  });
}

//  =========================================================================
//    Add Preview and View Letter Functions
//  =========================================================================

function showPreviewLetter() {
  const spec = state.selectedSpecialization;
  const treatment = state.selectedTreatment;
  const doctor = state.selectedDoctor;
  const date = state.selectedDate;
  const time = state.selectedTime;

  if (!spec || !treatment || !doctor || !date || !time) {
    showToast("Please complete all steps first.", "error");
    return;
  }

  // Build preview HTML (simplified – you can reuse the same style as backend)
  const patientName = "Patient Preview"; // We don't have real patient name in state; use placeholder
  const patientEmail = "patient@example.com";
  const patientPhone = "+1 (555) 000-0000";
  const patientAddress = "123 Patient St, City";

  const dateFormatted = new Date(date + "T00:00:00").toLocaleDateString(
    "en-US",
    {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    },
  );
  const timeFormatted = formatTime(time);

  const html = `
    <!DOCTYPE html>
    <html>
    <head><title>Appointment Letter Preview</title>
    <style>
      * { margin:0; padding:0; box-sizing:border-box; }
      body { font-family: 'Inter', sans-serif; background: #f5f0eb; padding:40px 20px; display:flex; justify-content:center; }
      .letter-container { max-width:800px; background:#fff; border-radius:20px; box-shadow:0 20px 60px rgba(44,24,16,0.15); overflow:hidden; }
      .letter-header { background:linear-gradient(135deg,#6b1d2a,#8a2a3a); color:#fff; padding:32px 40px; }
      .clinic-name { font-size:1.8rem; font-weight:700; }
      .clinic-details { font-size:0.8rem; opacity:0.7; margin-top:4px; }
      .letter-title { background:rgba(255,255,255,0.12); padding:4px 16px; border-radius:30px; display:inline-block; margin-top:12px; }
      .letter-body { padding:32px 40px; }
      .section { margin-bottom:28px; }
      .section-title { font-weight:700; text-transform:uppercase; color:#6b1d2a; border-bottom:2px solid #e8dfd4; padding-bottom:8px; margin-bottom:14px; font-size:0.85rem; }
      .info-grid { display:grid; grid-template-columns:1fr 1fr; gap:12px 24px; }
      .info-item .label { font-size:0.7rem; text-transform:uppercase; color:#7a6a5e; font-weight:600; }
      .info-item .value { font-size:0.95rem; font-weight:500; }
      .status-badge { background:#e6f7f0; color:#0f7a5a; padding:4px 16px; border-radius:30px; font-size:0.75rem; font-weight:700; display:inline-block; }
      .footer { text-align:center; font-size:0.75rem; color:#7a6a5e; border-top:1px solid #e8dfd4; padding-top:20px; margin-top:12px; }
      .actions { display:flex; gap:12px; justify-content:center; margin:24px 0; }
      .btn { padding:12px 28px; border-radius:30px; font-weight:600; border:none; cursor:pointer; }
      .btn-gold { background:#c9a84c; color:#2c1810; }
      .btn-outline { background:transparent; border:2px solid #d5c8b8; }
      @media print { .actions { display:none; } }
    </style>
    </head>
    <body>
      <div class="letter-container">
        <div class="letter-header">
          <div class="clinic-name">ClearView Eye Care</div>
          <div class="clinic-details">123 Vision Lane, Medical District, City, 10001<br>+1 (555) 123-4567 · info@clearview.eyecare</div>
          <div class="letter-title">Appointment Confirmation Letter (Preview)</div>
        </div>
        <div class="letter-body">
          <div class="section">
            <div class="section-title">Patient Information (Preview)</div>
            <div class="info-grid">
              <div class="info-item"><span class="label">Full Name</span><span class="value">${patientName}</span></div>
              <div class="info-item"><span class="label">Email</span><span class="value">${patientEmail}</span></div>
              <div class="info-item"><span class="label">Phone</span><span class="value">${patientPhone}</span></div>
              <div class="info-item"><span class="label">Address</span><span class="value">${patientAddress}</span></div>
            </div>
          </div>
          <div class="section">
            <div class="section-title">Appointment Details</div>
            <div class="info-grid">
              <div class="info-item"><span class="label">Date</span><span class="value">${dateFormatted}</span></div>
              <div class="info-item"><span class="label">Time</span><span class="value">${timeFormatted}</span></div>
              <div class="info-item"><span class="label">Status</span><span class="status-badge">Pending Confirmation</span></div>
              <div class="info-item"><span class="label">Treatment</span><span class="value">${treatment.name}</span></div>
            </div>
          </div>
          <div class="section">
            <div class="section-title">Doctor Information</div>
            <div class="info-grid">
              <div class="info-item"><span class="label">Doctor</span><span class="value">${doctor.name}</span></div>
              <div class="info-item"><span class="label">Specialization</span><span class="value">${doctor.specialization}</span></div>
              <div class="info-item"><span class="label">Experience</span><span class="value">${doctor.experience}</span></div>
              <div class="info-item"><span class="label">Fee</span><span class="value">$${doctor.fee}</span></div>
            </div>
          </div>
          <div class="footer">
            This is a preview. Actual letter will be generated after booking confirmation.
            <br>© ${new Date().getFullYear()} ClearView Eye Care. All rights reserved.
          </div>
        </div>
      </div>
      <div class="actions">
        <button onclick="window.print()" class="btn btn-gold">Print / Download PDF</button>
        <button onclick="window.close()" class="btn btn-outline">Close</button>
      </div>
    </body>
    </html>
  `;

  const win = window.open("", "_blank", "width=800,height=600");
  if (win) {
    win.document.write(html);
    win.document.close();
  } else {
    showToast("Popup blocked. Please allow popups for this site.", "error");
  }
}

function viewActualLetter(bookingId) {
  if (!bookingId) {
    showToast("No booking ID found.", "error");
    return;
  }
  const url = `../../backend/appointment_letter.php?booking_id=${bookingId}`;
  window.open(url, "_blank");
}

// ============================================================
// EXPOSE FUNCTIONS GLOBALLY - UNCHANGED
// ============================================================

// Make functions globally accessible for inline onclick
window.showPreviewLetter = showPreviewLetter;
window.viewActualLetter = viewActualLetter;
window.selectSpecialization = selectSpecialization;
window.selectTreatment = selectTreatment;
window.selectDoctor = selectDoctor;
window.selectDate = selectDate;
window.selectTime = selectTime;
window.confirmBooking = confirmBooking;
window.checkTerms = checkTerms;

console.log("Home.js loaded successfully");
