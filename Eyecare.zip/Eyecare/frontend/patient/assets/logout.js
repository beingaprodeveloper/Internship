// frontend/assets/js/logout.js
// Logout functionality for all pages

async function logout() {
  try {
    const response = await fetch("../../backend/logout.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
    });

    const data = await response.json();

    if (data.status === "success") {
      window.location.href = "../../login.html";
    } else {
      // Fallback redirect
      window.location.href = "../../login.html";
    }
  } catch (error) {
    console.error("Logout error:", error);
    // Fallback redirect
    window.location.href = "../../login.html";
  }
}

// Attach logout to any element with id="logoutBtn"
document.addEventListener("DOMContentLoaded", () => {
  const logoutBtn = document.getElementById("logoutBtn");
  if (logoutBtn) {
    logoutBtn.addEventListener("click", (e) => {
      e.preventDefault();
      logout();
    });
  }
});
